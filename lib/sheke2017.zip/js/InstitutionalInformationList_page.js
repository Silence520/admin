$(function() {
	//»ñÈ¡»ú¹¹ÀàÐÍ
    var data={
        id:0,
        type:2
    }
	
	app.post(app.url.api_base+"dataQuery/queryData.do",data,
         function(req) { 
              if(req.code==0){
                var html='<option value="">请选择</option>';
                var data=req.items;
                 $.each(data,function(i,v){
                    html+='<option value="'+v.id+'">'+v.value+'</option>';
                 })
                 $('#companyRelationship').html(html);
               }else{
                 Prompt.show(req.message)
               }
         },
	false);

    if(app.getItem('user') !=''){
        function loadData(){
            if(window.location.hash){
                var num=window.location.hash;
                num=(num.split('=')[1]);
            }else{
                var num=1;
            }
            this.data={
                pageNo: num,
                everyPage: 10,
                userToken:app.getItem('userToken'),
                userId:app.getItem('userId'),
                companyId:app.getItem('companyId'),
                type:'',
                name:''
            }
            this.init();
        }
    }else{
        app.go('login.html')
    }

    //原型读写数据
    loadData.prototype.init=function(){
        var _this=this;
        loadList(_this.data)
        var count=0;
        var indexpage=true;

        //线索搜索提交
        $(document).on('click', '.btnsearch', function() {
            var SeaName = $('#SeaName').val().trim();
            var SeaType=$('#companyRelationship option:selected ').val()
            var SeaTypeName=$('#companyRelationship option:selected ').html()
            var html = '<span>热搜词：</span>';
            if (SeaName != '') {
                html += '<span>' + SeaName + '</span>';
            }
            if (SeaType != '') {
                html += '<span>' + SeaTypeName + '</span>';
            }
            
            _this.data.name = SeaName;
            _this.data.type = SeaType;
            _this.data.pageNo = 1;
            _this.data.everyPage = 10;
          
           
            $('.searchCriteria').html(html)
            if ($('.searchCriteria').find('span').length > 1) {
                $('#pageToolbar,.table').hide();
                loadList(_this.data);
            } else {
                Prompt.show("搜索条件为空！", '操作提示', function() {});
                return false;
            }

        });

        //重置搜索条件
        $(document).on('click', '.iRefresh', function() {
                _this.data.name = '';
                _this.data.type = '';
                _this.data.pageNo = 1;
                _this.data.everyPage = 10;
                // 清空hash
                window.location.hash='';
                loadList(_this.data);
                $('.searchCriteria').html('<span>热搜词：</span>')

        });

        //表格分页
         function pagefen(page, count) {
              $('#pageToolbar').Paging({
                  pagesize: 10,
                  count: count,
                  toolbar: false,
                  callback: function(page, size, count) {
                      if (page == NaN) {
                          page = parseInt($('#pageToolbar .focus').html())
                      }
                      var data = _this.data;
                      data.pageNo = page;
                      loadList(data);
                  },
              });
         };
    	
        //加载数据
         function loadList(dataarray){ 
            app.post( app.url.api_base+"common/getCompanyList.do",dataarray,
                     function(req) { 
                          if(req.code==0){
                             //清空个数据
                             $('.table tbody').html('')
                            var data=req.items;
                            if(data.length>0){
                                var html='';
                                $.each(data,function(i,v){
                                    html+='<tr>';
                                    html+='<td>'+v.name;
                                    html+='</td>';
                                    html+='<td>'+v.code;
                                    html+='</td>';
                                    html+='<td>'+v.typeStr;
                                    html+='</td>';
                                    html+='<td>'+'一级机构';
                                    html+='</td>';
                                    html+='<td>'+3;
                                    html+='</td>';
                                    html+='<td>';
                                    html+='<a href="'+v.id+'">查看</a>';
                                    html+='<a href="'+v.id+'">修改</a>';
                                    html+='<span>刪除</span>';
                                    html+='</td>';
                                    html+='</tr>';

                                });
                                 $('.table tbody').html(html)
                                 count=req.totalcount;
                                 if (indexpage ==true ) {
                                     $('#pageToolbar').html('');
                                     pagefen(_this.data.everyPage,count);
                                     indexpage=false;
                                 }
                                   $('.table,#pageToolbar').show();
                                   $('.Inothing').hide();
                            }else{
                                 indexpage=true;
                                 $('.table,#pageToolbar').hide();
                                 $('.Inothing').show();
                                 $('.tab-content').html('<p class="NoData">暂无数据！</p>');
                                 //清除分页
                                 $('#pageToolbar .ui-paging-container').remove();
                            }
                           }else{
                             Prompt.show(req.message)
                           }
                 },true);
        }

        //线索搜索提交
        $(document).on('click', '.btnadd', function() {
            var TypeName = $('#TypeName').val().trim();
            var TypeDesc = $('#TypeDesc').val().trim();
            var saveData = {
                value:TypeName,
                desc:TypeDesc,
                userToken:app.getItem('userToken'),
                userId:app.getItem('userId'),
                companyId:app.getItem('companyId')
            }
            if (TypeName == null || TypeName == '') {
                Prompt.show("机构类型名称为空！", '操作提示', function() {});
                return false;
            }
            if (TypeDesc == null || TypeDesc == '') {
                Prompt.show("机构类型描述为空！", '操作提示', function() {});
                return false;
            }
            saveCompanyType(saveData);
        });

        //保存机构类型
        function saveCompanyType(data){ 
            app.post( app.url.api_base+"dataQuery/saveCompanyType.do",data,
                     function(req) { 
                          Prompt.show(req.message);
                           if(req.code==0){
                               $('#TypeName').val(null);
                               $('#TypeDesc').val(null);
                           }
                 },true);
        }
    }

    new loadData();
});