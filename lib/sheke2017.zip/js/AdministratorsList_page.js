$(function() {
	//默认数据
    var data={
        userToken:app.getItem('userToken'),
        userId:app.getItem('userId')
    }

    app.post(app.url.api_base+"role/getRoleListForSelect.do",data,
         function(req) { 
              if(req.code==0){
                var html='<option value="">请选择</option>';
                var data=req.items;
                 $.each(data,function(i,v){
                    html+='<option value="'+v.id+'">'+v.roleName+'</option>';
                 })
                 $('#userRoleType').html(html);
               }else{
                 Prompt.show(req.message)
               }
         },false);

    if(app.getItem('user') !=''){
        function loadData(){
            if(window.location.hash){
                var num=window.location.hash;
                num=(num.split('=')[1]);
            }else{
                var num=1;
            }
            this.data={
                pageNo: num,
                everyPage: 10,
                userToken:app.getItem('userToken'),
                userId:app.getItem('userId')
            }
            this.init();
        }
    }else{
        app.go('login.html')
    }

    //原型读写数据
    loadData.prototype.init=function(){
        var _this=this;
        loadList(_this.data)
        var count=0;
        var indexpage=true;

        //线索搜索提交
        $(document).on('click', '.btnsearch', function() {
            var userAccount = $('#userAccount').val().trim();
            var userIsDisable = $('#userIsDisable option:selected ').val();
            var userIsDisableName=$('#userIsDisable option:selected ').html();
            var userCompany = $('#userCompany option:selected ').val();
            var userCompanyName=$('#userCompany option:selected ').html();
            var userRoleType = $('#userRoleType option:selected ').val();
            var userRoleTypeName=$('#userRoleType option:selected ').html();
            var userSysType = $('#userSysType option:selected ').val();
            var userSysTypeName=$('#userSysType option:selected ').html();
            var html = '<span>热搜词：</span>';
            if (userAccount) {
                html += '<span>' + userAccount + '</span>';
            }
            if (userIsDisableName || userIsDisableName != '请选择') {
                html += '<span>' + userIsDisableName + '</span>';
            }
            if (userCompanyName  || userCompanyName != '请选择') {
                html += '<span>' + userCompanyName + '</span>';
            }
            if (userRoleTypeName  || userRoleTypeName != '请选择') {
                html += '<span>' + userRoleTypeName + '</span>';
            }
            if (userRoleTypeName  || userRoleTypeName != '请选择') {
                html += '<span>' + userSysTypeName + '</span>';
            }
            _this.data.userName = userAccount;
            _this.data.type = userSysType;
            _this.data.roleId = userRoleType;
            _this.data.isDisable = userIsDisable;
            _this.data.companyId = userCompany;
            _this.data.pageNo = 1;
            _this.data.everyPage = 10;
           
            $('.searchCriteria').html(html);
            loadList(_this.data);

        });

        //重置搜索条件
        $(document).on('click', '.iRefresh', function() {
                _this.data.userName = '';
                _this.data.type = '';
                _this.data.roleId = '';
                _this.data.isDisable = '';
                _this.data.companyId = '';
                _this.data.pageNo = 1;
                _this.data.everyPage = 10;
                loadList(_this.data);
                $('.searchCriteria').html('<span>热搜词：</span>')

        });

        //表格分页
         function pagefen(page, count) {
              $('#pageToolbar').Paging({
                  pagesize: 10,
                  count: count,
                  toolbar: false,
                  callback: function(page, size, count) {
                      if (page == NaN) {
                          page = parseInt($('#pageToolbar .focus').html())
                      }
                      var data = _this.data;
                      data.pageNo = page;
                      loadList(data);
                  },
              });
         };

        //删除账号
        $(document).on('click','.table .del' ,function(){
          var deleteData={
                    id:$(this).attr('dataid'),
                    userToken:app.getItem('userToken'),
                    userId:app.getItem('userId'),
                    companyId:app.getItem('companyId')
                }
                app.post( app.url.api_base+"adminUser/deleteAdminUser.do",deleteData,
                         function(req) { 
                              Prompt.show(req.message);
                               if(req.code==0){
                                   loadList(_this.data);
                               }
                     },true);
        });

        //启用/禁用账号
        $(document).on('click','.table .isDisable' ,function(){
          var deleteData={
                    id:$(this).attr('dataid'),
                    userToken:app.getItem('userToken'),
                    userId:app.getItem('userId'),
                    companyId:app.getItem('companyId'),
                    isDisable:$(this).attr('isDisableValue')
                }
                app.post( app.url.api_base+"adminUser/updateAdminUser.do",deleteData,
                         function(req) { 
                              Prompt.show(req.message);
                               if(req.code==0){
                                   loadList(_this.data);
                               }
                     },true);
        });
    	
        //加载数据
        function loadList(dataarray){ 
            app.post( app.url.api_base+"adminUser/queryAdminUserForPage.do",dataarray,
                     function(req) { 
                          if(req.code==0){
                             //清空个数据
                             $('.table tbody').html('')
                            var data=req.items;
                            if(data.length>0){
                                var html='';
                                $.each(data,function(i,v){
                                    html+='<tr>';
                                    html+='<td>'+(i + 1);
                                    html+='</td>';
                                    html+='<td>'+v.userName;
                                    html+='</td>';
                                    html+='<td>'+v.typeStr;
                                    html+='</td>';
                                    html+='<td>'+v.roleName;
                                    html+='</td>';
                                    html+='<td>'+v.companyName;
                                    html+='</td>';
                                    html+='<td>'+v.companyType;
                                    html+='</td>';
                                    html+='<td>'+v.lastLoginDate;
                                    html+='</td>';
                                    html+='<td>'+v.isDisableStr;
                                    html+='</td>';
                                    // html+='<td>'+v.createUser;
                                    // html+='</td>';
                                    // html+='<td>'+v.updateUser;
                                    html+='</td>';
                                    html+='<td>';
                                    html+='<a href="ManagingUsers.html?NO='+v.id+'">查看</a>';
                                    html+='<a href="ManagingUsers.htmlNO='+v.id+'">修改</a>';
                                    html+='<span class="del" dataid="'+v.id+'">刪除</span>';
                                    if (v.isDisable == 0) {
                                        html+='<span class="isDisable" dataid="'+v.id+'" isDisableValue="1">禁用</span>';
                                    } else {
                                        html+='<span class="isDisable" dataid="'+v.id+'" isDisableValue="0">启用</span>';
                                    }
                                    html+='</td>';
                                    html+='</tr>';

                                });
                                 $('.table tbody').html(html)
                                 count=req.totalcount;
                                 if (indexpage ==true ) {
                                     $('#pageToolbar').html('');
                                     pagefen(_this.data.everyPage,count);
                                     indexpage=false;
                                 }
                                   $('.table,#pageToolbar').show();
                                   $('.Inothing').hide();
                            }else{
                                 indexpage=true;
                                 $('.table,#pageToolbar').hide();
                                 $('.Inothing').show();
                                 $('.tab-content').html('<p class="NoData">暂无数据！</p>');
                                 //清除分页
                                 $('#pageToolbar .ui-paging-container').remove();
                            }
                           }else{
                             Prompt.show(req.message)
                           }
                 },true);
        };
    }

    new loadData();
});