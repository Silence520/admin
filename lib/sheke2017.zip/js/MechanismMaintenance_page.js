$(function(){
		//判断是否登陆
		if(app.getItem('user') !=''){
			function loadData(){
				this.data={
					
				}
				this.init();
			}
		}else{
			app.go('login.html')
		}


		loadData.prototype.init=function(){
			var _this=this;
			//判断是修改还是新建
			if(app.getParameterByName('No')!=''){


			}else{
				//获取机构地点
				app.post(app.url.api_base+"",{},
			     function(req) { 
			          if(req.code==0){
			            	var dat=req.items;
			            	var html='';
			            	$.each(data,function(i,v){
			            		html+='<option value="'+v.id+'" >'+v.roleName+'</option>'
			            	});
			            	$('#MmCity').html(html)

			           }else{
			             Prompt.show(req.message)
			           }
			     },true);
			}
			//返回
			$(document).on('click','goBack',function(){
				app.back();
			})
			//提交数据
			$(document).on('click','DeSubmine',function(){
				var OrganizationNumber=$('#OrganizationNumber').val();
				var DocumentType= $('#DocumentType option:selected').attr('value');
				var TypeInstitution= $('#TypeInstitution option:selected').attr('value');
				var isAvailable = $("input[name='isAvailable']:checked").val();
				var MmCity= $('#MmCity option:selected').attr('value');
				var Mmregion= $('#Mmregion option:selected').attr('value');
				if (OrganizationNumber == '') {
				    Prompt.show('机构编号不能为空!', '操作提示', function() {});
				    return false;
				}
				if (MmCertificates == '') {
				    Prompt.show('证件类型不能为空!', '操作提示', function() {});
				    return false;
				}
				if (TypeInstitution == '') {
				    Prompt.show('机构类型不能为空!', '操作提示', function() {});
				    return false;
				}
				if (isAvailable == '') {
				    Prompt.show('是否有效不能为空!', '操作提示', function() {});
				    return false;
				}
				if (MmCity == '') {
				    Prompt.show('一级城市不能为空!', '操作提示', function() {});
				    return false;
				}
				if (Mmregion == '') {
				    Prompt.show('二级城市不能为空!', '操作提示', function() {});
				    return false;
				}
				var data={}
				if(app.getParameterByName('No')!=''){//修改
					data.id=app.getParameterByName('No');
					app.post(app.url.api_base+"",data,
				     function(req) { 
				          if(req.code==0){
				          	 Prompt.show('提交成功！')
				           }else{
				             Prompt.show(req.message)
				           }
				     },true);
				}else{ //新建
					app.post(app.url.api_base+"",data,
				     function(req) { 
				          if(req.code==0){
				          	 Prompt.show('提交成功！')
				           }else{
				             Prompt.show(req.message)
				           }
				     },true);
				}
				
				
			})

		}

		new loadData();
})