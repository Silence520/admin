
$(function() {

    //获取机构类型
    var data={
        id:0,
        type:2
    }
    app.post(app.url.api_base+"dataQuery/queryData.do",data,
         function(req) { 
              if(req.code==0){
                var html='<option value="">请选择机构类型</option>';
                var data=req.items;
                 $.each(data,function(i,v){
                    html+='<option value="'+v.id+'">'+v.value+'</option>';
                 })
                 $('#LoginType').html(html);
               }else{
                 Prompt.show(req.message)
               }
         },false);

    //获取所属机构
     $(document).on('change','#LoginType',function(){
         addjigou($(this).val());
         var html='<option value="">请选择机构类型</option>';
          $('#LoginMechanism').html(html);
     })
     
     // //获取选中的所属机构
     // $(document).on('change','#LoginMechanism',function(){
         
     // })   



    //登录
    $('body').on('click', '.butsubmit', function() {
        var userName = $('#userName').val();
        var userpase = $('#userpase').val();
        var yanzheng = $('#yanzheng').val().toLowerCase();
        var checkCode = $('#checkCode').html().toLowerCase();
        var LoginType = $('#LoginType option:selected').attr('value');
        var LoginMechanism = $('#LoginMechanism option:selected').attr('value');
        if (userName == "") {
            Prompt.show("用户名不能为空!",'提示',function(){});
            return false;
        }
        if (userpase == "") {
            Prompt.show("密码不能为空",'提示',function(){});
            return false;
        }
        if(yanzheng==''){
             Prompt.show("验证码为空",'提示',function(){});
            return false;
        }
        if(yanzheng!=checkCode){
             Prompt.show("验证码错误",'提示',function(){});
            return false;
        }
        if (LoginType == "") {
            Prompt.show("请选择机构类型",'提示',function(){});
            return false;
        }
        if(LoginMechanism==''){
            Prompt.show("请选择所属机构",'提示',function(){});
            return false;
        }
        var hash = $.md5(userpase);
        var data={
            userName: userName,
            password:hash,
            companyId:LoginMechanism,
        };
       app.post(app.url.api_base+"login/backUserLogin.do",data,
            function(req) { 
                 if(req.code==0){
                    app.addItem('companyId',req.data.companyId);
                    app.addItem('userName',req.data.userName);
                    app.addItem('userId',req.data.id);
                    app.addItem('userToken',req.data.userToken);
                    app.go('home.html');
                  }else{
                    Prompt.show(req.message)
                  }
            },false);
    });

     //获取所属机构
    function addjigou(num){
        var data={
            type:num
        }
        app.post(app.url.api_base+"common/getCompanyListByType.do",data,
             function(req) { 
                  if(req.code==0){
                    var html='<option value="">请选择机构类型</option>';
                    var data=req.items;
                     $.each(data,function(i,v){
                        html+='<option value="'+v.id+'">'+v.name+'</option>';
                     })
                     $('#LoginMechanism').html(html);
                   }else{
                     Prompt.show(req.message)
                   }
             },false);
    }


})

