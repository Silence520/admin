$(function() {
	//默认数据
    var data={}
	
    if(app.getItem('user') !=''){
        function loadData(){
            this.data={
                userToken:app.getItem('userToken'),
                userId:app.getItem('userId'),
                companyId:app.getItem('companyId'),
                menuName:''
            }
            this.init();
        }
    }else{
        app.go('login.html')
    }

    //原型读写数据
    loadData.prototype.init=function(){
        var _this=this;
        loadList(_this.data)
        var count=0;

        //线索搜索提交
        $(document).on('click', '.btnsearch', function() {
            var menuName = $('#menuName').val().trim();
            var html = '<span>热搜词：</span>';
            if (menuName != '') {
                html += '<span>' + menuName + '</span>';
            }
            
            _this.data.name = menuName;
           
            $('.searchCriteria').html(html)
            loadList(_this.data);

        });

        //重置搜索条件
        $(document).on('click', '.iRefresh', function() {
                _this.data.name = '';
                loadList(_this.data);
                $('.searchCriteria').html('<span>热搜词：</span>')

        });
    	
        //加载数据
        function loadList(dataarray){ 
            app.post( app.url.api_base+"menu/queryMenuList.do",dataarray,
                     function(req) { 
                          if(req.code==0){
                             //清空个数据
                             $('.table tbody').html('')
                            var data=req.items;
                            if(data.length>0){
                                var html='';
                                $.each(data,function(i,v){
                                    html+='<tr>';
                                    html+='<td>'+(i + 1);
                                    html+='</td>';
                                    html+='<td>'+v.name;
                                    html+='</td>';
                                    html+='<td>'+v.level;
                                    html+='</td>';
                                    html+='</tr>';

                                });
                                $('.table tbody').html(html);
                                $('.Inothing').hide();
                            }else{
                                 $('.tab-content').html('<p class="NoData">暂无数据！</p>');
                            }
                           }else{
                             Prompt.show(req.message)
                           }
                 },true);
        };
    }

    new loadData();
});