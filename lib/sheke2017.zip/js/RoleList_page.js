$(function() {
	//默认数据
    var data={}

    if(app.getItem('user') !=''){
        function loadData(){
            if(window.location.hash){
                var num=window.location.hash;
                num=(num.split('=')[1]);
            }else{
                var num=1;
            }
            this.data={
                pageNo: num,
                everyPage: 10,
                userToken:app.getItem('userToken'),
                userId:app.getItem('userId'),
                companyId:app.getItem('companyId'),
                roleCode:'',
                roleName:''
            }
            this.init();
        }
    }else{
        app.go('login.html')
    }

    //原型读写数据
    loadData.prototype.init=function(){
        var _this=this;
        loadList(_this.data)
        var count=0;
        var indexpage=true;

        //线索搜索提交
        $(document).on('click', '.btnsearch', function() {
            var roleCode = $('#roleCode').val().trim();
            var roleName = $('#roleName').val().trim();
            var html = '<span>热搜词：</span>';
            if (roleCode != '') {
                html += '<span>' + roleCode + '</span>';
            }
            if (roleName != '') {
                html += '<span>' + roleName + '</span>';
            }
            
            _this.data.roleCode = roleCode;
            _this.data.roleName = roleName;
            _this.data.pageNo = 1;
            _this.data.everyPage = 10;
          
           
            $('.searchCriteria').html(html)
            if ($('.searchCriteria').find('span').length > 1) {
                $('#pageToolbar,.table').hide();
            } 
            loadList(_this.data);

        });

        //重置搜索条件
        $(document).on('click', '.iRefresh', function() {
                _this.data.roleCode = '';
                _this.data.roleName = '';
                _this.data.pageNo = 1;
                _this.data.everyPage = 10;
                // 清空hash
                window.location.hash='';
                loadList(_this.data);
                $('.searchCriteria').html('<span>热搜词：</span>')

        });

        //表格分页
         function pagefen(page, count) {
              $('#pageToolbar').Paging({
                  pagesize: 10,
                  count: count,
                  toolbar: false,
                  callback: function(page, size, count) {
                      if (page == NaN) {
                          page = parseInt($('#pageToolbar .focus').html())
                      }
                      var data = _this.data;
                      data.pageNo = page;
                      loadList(data);
                  },
              });
         };

        //删除角色
        $(document).on('click','.table .del' ,function(){
          var deleteData={
                    id:$(this).attr('dataid'),
                    userToken:app.getItem('userToken'),
                    userId:app.getItem('userId'),
                    companyId:app.getItem('companyId')
                }
                app.post( app.url.api_base+"role/deleteRole.do",deleteData,
                         function(req) { 
                              Prompt.show(req.message);
                               if(req.code==0){
                                   loadList(_this.data);
                               }
                     },true);
        });
    	
        //加载数据
        function loadList(dataarray){ 
            app.post( app.url.api_base+"role/getRoleList.do",dataarray,
                     function(req) { 
                          if(req.code==0){
                             //清空个数据
                             $('.table tbody').html('')
                            var data=req.items;
                            if(data.length>0){
                                var html='';
                                $.each(data,function(i,v){
                                    html+='<tr>';
                                    html+='<td>'+(i + 1);
                                    html+='</td>';
                                    html+='<td>'+v.roleCode;
                                    html+='</td>';
                                    html+='<td>'+v.roleName;
                                    html+='</td>';
                                    html+='<td>'+v.roleDesc;
                                    html+='</td>';
                                    html+='<td>';
                                    html+='<a href="RoleInformation.html?NO='+v.id+'">查看</a>';
                                    html+='<a href="RoleInformation.html?NO='+v.id+'">修改</a>';
                                    html+='<span class="del" dataid="'+v.id+'">刪除</span>';
                                    html+='</td>';
                                    html+='</tr>';

                                });
                                 $('.table tbody').html(html)
                                 count=req.totalcount;
                                 if (indexpage ==true ) {
                                     $('#pageToolbar').html('');
                                     pagefen(_this.data.everyPage,count);
                                     indexpage=false;
                                 }
                                   $('.table,#pageToolbar').show();
                                   $('.Inothing').hide();
                            }else{
                                 indexpage=true;
                                 $('.table,#pageToolbar').hide();
                                 $('.Inothing').show();
                                 $('.tab-content').html('<p class="NoData">暂无数据！</p>');
                                 //清除分页
                                 $('#pageToolbar .ui-paging-container').remove();
                            }
                           }else{
                             Prompt.show(req.message)
                           }
                 },true);
        };
    }

    new loadData();
});