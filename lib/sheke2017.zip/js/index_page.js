$(function() {
    if (app.getItem('userId') != null) {
        function indexpage() {
            this.data = {
                name: '',
                age: '',
                gender: '',
                mobile: '',
                telePhone: '',
                relationshipType: '',
                schoolName: '',
                cityCode: '',
                districtCode: '',
                cityCode: '',
                storeId: '',
                subjectId: '',
                gradeId: '',
                courseId: '',
                creatorId: '',
                childSourceId: '',
                sourceId: '',
                leadPeriods: '',
                owner: '',
                createDate: '',
                pageIndex: '',
                everyPage: '',
                sort: '',
                sortName: '',
                status: '',
                lastUpdateTime: '',
            };
            this.init()
        }

    } else {
        app.go('login.html')
    }

    indexpage.prototype.init = function() {
        var _this = this;
        //判断已联系人关系是否必填 TMK非必填
        if (app.getItem('role') == 'TMKManager' || app.getItem('role') == 'TMKStaff') {
            $('.tmkhide').hide();
        };
        //表格数据请求
        $('.username').html(app.getItem('userName'));
        //初始化判断权限
        if (app.getItem('role') == 'TMKManager' || app.getItem('role') == 'MarketManager') {
            $('.Administration .li2').show();
            $('.Administration .li3').show();
            $('.Administration .li5').show();
        } else {
            $('.li1 a').html('已提交');
            $('.li4 a').html('待处理');
        }
        var itype = app.getParameterByName('itype');
        $('.Administrationtab li').removeClass('active');
        $('.Administrationtab li[itype=' + itype + ']').addClass('active');

        //管理者 判断角色
        if (itype == 0 || itype == null) {
            if (app.getItem('role') == 'TMKManager' || app.getItem('role') == 'MarketManager') {
                // $('.Administration .li2').show();
                // $('.Administration .li3').show();
                $('.thediter,.istatus').hide();
                $('.table , #pageToolbar').hide();
                //$('#ClueDetail .btn-primary').html('清除线索跟进记录')
                //管理者登陆初始化
                console.log('管理者')
                this.data = {
                    leadPeriods: 'AUDITED',
                    owner: false,
                    pageIndex: 1,
                    everyPage: 10,
                    sort: 'DESC',
                    sortName: 'lastUpdateTime',
                }
                adddata(this.data, 0);
                $('.searchCriteria').html('<span>热搜词：</span>');
            } else { //操作者
                console.log('操作者')
                $('.table , #pageToolbar').hide();
                this.data = {
                    leadPeriods: 'UNAUDITED,AUDITED',
                    owner: true,
                    pageIndex: 1,
                    everyPage: 10,
                    sort: 'DESC',
                    sortName: 'lastUpdateTime',
                }
                adddata(this.data, 0);
                // $('.li1 a').html('已提交');
                // $('.li4 a').html('未提交');
                //搜索操作人
                $('.Operatorgroup').hide();
                $('.searchCriteria').html('<span>热搜词：</span>')
            };
        }


        var type = app.getParameterByName('itype');

        if (type == 1) { //待审批
            console.log('待审批');
            $('.thTrial').show();
            $('.thdistribution,.thEdit, .thediter').hide();
            $('.thediter,.istatus').hide();
            $('.table , #pageToolbar').hide();
            _this.data = {
                leadPeriods: 'UNAUDITED',
                owner: false,
                pageIndex: 1,
                everyPage: 10,
                sort: 'ASC',
                sortName: 'lastUpdateTime',
            };
            adddata(_this.data, 1);
            $('.searchCriteria').html('<span>热搜词：</span>')
        } else if (type == 2) { //重新分配
            console.log('重新分配')
            $('.thTrial,.thEdit').hide();
            $('.thdistribution').show();
            $('.thediter,.istatus').hide();
            $('.table , #pageToolbar').hide();
            _this.data = {
                leadPeriods: 'REASSIGN',
                owner: false,
                pageIndex: 1,
                everyPage: 10,
                sort: 'DESC',
                sortName: 'lastUpdateTime',
            };
            adddata(_this.data, 2);
            $('.searchCriteria').html('<span>热搜词：</span>')
        } else if (type == 3) { //未提交
            console.log('未提交')
            $('.thTrial,.thdistribution').hide();
            $('.thEdit,.istatus').show();
            $('.thediter').hide();
            $('.table , #pageToolbar').hide();
            _this.data = {
                leadPeriods: 'UNSUMIT,AUDITEDFAIL',
                owner: true,
                pageIndex: 1,
                everyPage: 10,
                sort: 'DESC',
                sortName: 'createTime',
            };
            adddata(_this.data, 3);
            $('.searchCriteria').html('<span>热搜词：</span>')
        } else if (type == 0) {
            $('.table , #pageToolbar').hide();
            $('.thTrial,.thdistribution,.thEdit,.istatus').hide();
            //TMKStaff TMKManager MarketStaff MarketManager
            if (app.getItem('role') == 'TMKStaff' || app.getItem('role') == 'MarketStaff') { //已提交
                console.log('已提交')
                $('.thediter').show();
                $('.istatus').show();
                _this.data = {
                    leadPeriods: 'UNAUDITED,AUDITED',
                    owner: true,
                    pageIndex: 1,
                    everyPage: 10,
                    sort: 'DESC',
                    sortName: 'lastUpdateTime',
                }
                adddata(_this.data, 0);
                $('.searchCriteria').html('<span>热搜词：</span>') //已审批
            } else if (app.getItem('role') == 'TMKManager' || app.getItem('role') == 'MarketManager') { //a-zA-Z0-9
                console.log('已审批')
                _this.data = {
                    leadPeriods: 'AUDITED',
                    owner: false,
                    pageIndex: 1,
                    everyPage: 10,
                    sort: 'DESC',
                    sortName: 'lastUpdateTime',
                }
                adddata(_this.data, 0);
                $('.searchCriteria').html('<span>热搜词：</span>')
            }
        }

        //修改密码
        $(document).on('click', '#ChangePass .btn-primary', function() {
            var old = $('#oldpass').val();
            var newpass = $('#newpass').val();
            var again = $('#querenpass').val();
            if (old == '') {
                Prompt.show('旧密码不能为空!', '操作提示', function() {});
                return false;
            }
            if (newpass == '') {
                Prompt.show('新密码不能为空!', '操作提示', function() {});
                return false;
            }
            if (again == '') {
                Prompt.show('确认密码不能为空!', '操作提示', function() {});
                return false;
            }
            if (newpass != again) {
                Prompt.show('两次密码不一致!', '操作提示', function() {});
                return false;
            }

            var data = {
                'oldPassword': $.md5(old),
                'newPassword': $.md5(newpass),
            };
            app.posttoken(app.url.api_base + "leads/change-password", data,
                function(req) {
                    if (req.code == 0) {
                        $('#ChangePass').modal('hide');
                        Prompt.show(req.message);

                    } else {
                        Prompt.show(req.message);
                    }
                });
        })

        //退出登陆 ok
        $(document).on('click', '.SignOut', function() {
            var data = {
                accessToken: app.getItem('userToken')
            }
            app.posttoken(app.url.api_base + "logout", data,
                function(req) {
                    if (req.code == 0) {
                        app.removeItem('role');
                        app.removeItem('userName');
                        app.removeItem('userId');
                        app.removeItem('userToken');
                        app.go('login.html');
                    } else {
                        Prompt.show(req.message);
                    }
                });
        });

        //查看线索详情
        $(document).on('click', '.table img', function() {
            $('#ClueDetail').modal('show');
            var numid = $(this).parents('tr').attr('id');
            // console.log(numid)
        });

        //重值搜索条件
        $(document).on('click', '.iRefresh', function() {
            var type = $('.Administrationtab .active').attr('itype');
            //adddata(type);
        });

        //搜索弹框
        $(document).on('click', '.ISearch', function() {
            $('#search').find('input:text').val('');
            $('#searegion option').remove();
            $('#SeaClue option').remove();
            $('#SeaCluetwo option').remove();
            $('#SeaBranch option').remove();
            $('#SeaCourse option').remove();
            $('#Seaclass option').remove();
            $('#Seaclass option').remove();
            $('#SeaSubject option').remove();
            $('.Seaclassbox,.SeaSubjectbox').hide();
            // $("#SeaRelationship").get(0).selectedIndex = 0;
            $('input:radio[name="searchSEX"]').attr('checked', false);
            $('input:radio[name="sea"]').attr('checked', false);
            //获取城市
            app.posttoken(app.url.api_base + "selections/citys", {},
                function(req) {
                    if (req.code == 0) {
                        var data = req.data.citys;
                        if (data.length > 0) {
                            var html = '<option value="">请选择</option>';
                            $.each(data, function(i, v) {
                                html += '<option value="' + v.id + '">' + v.text + '</option>'
                            });
                            $('#SeaCity').html(html);
                        }
                    } else {
                        Prompt.show(req.message);
                    }
                });
            //线索来源
            app.posttoken(app.url.api_base + "selections/first-sources", {},
                function(req) {
                    if (req.code == 0) {
                        var data = req.data.sources;
                        if (data.length > 0) {
                            var html = '<option value="">请选择</option>';
                            $.each(data, function(i, v) {
                                html += '<option value="' + v.id + '">' + v.text + '</option>'
                            });
                            $('#SeaClue').html(html);
                        }
                    } else {
                        Prompt.show(req.message);
                    }
                });
            //获取操作人
            app.posttoken(app.url.api_base + "selections/staffs", {},
                function(req) {
                    if (req.code == 0) {
                        var data = req.data.staffs;
                        if (data.length > 0) {
                            var html = '<option value="">请选择</option>';
                            $.each(data, function(i, v) {
                                html += '<option value="' + v.id + '">' + v.text + '</option>'
                            });
                            $('#SeaOperator').html(html);
                        }
                    } else {
                        Prompt.show(req.message);
                    }
                });
            //获取最新跟进状态
            app.posttoken(app.url.api_base + "selections/lead-status", {},
                function(req) {
                    if (req.code == 0) {
                        var data = req.data.statusMappers;
                        if (data.length > 0) {
                            var html = '<option value="">请选择</option>';
                            $.each(data, function(i, v) {
                                html += '<option value="' + v.id + '">' + v.text + '</option>'
                            });
                            $('#SeaStatus').html(html);
                        }
                    } else {
                        Prompt.show(req.message);
                    }
                });
        });

        //验证手机号码
        $(document).on('focusout', '#SeaPhone', function() {
            var filter = /^1\d{10}$/; //手机号
            var phone = $(this).val();
            if (phone != '') {
                if (filter.test(phone) == false) {
                    Prompt.show("手机号格式错误", '操作提示', function() {});
                    return false;
                }
            }
        });

        //判断选择二级线索来源的时候是否已选择一级
        $(document).on('click', '#searegion', function() {
            if ($(this).find('option').length <= 1) {
                Prompt.show("请先输入城市", '操作提示', function() {});
                return false;
            }
        });

        //判断选择二级线索来源的时候是否已选择一级
        $(document).on('click', '#SeaCluetwo', function() {
            if ($(this).find('option').length <= 1) {
                Prompt.show("请先输入一级来源线索", '操作提示', function() {});
                return false;
            }
        });

        //选择二级线索来源
        $(document).on('change', '#SeaClue', function() {
            // console.log($('#SeaClue').val())
            if ($('#AddSource').val() == '请选择') {
                Prompt.show('数据不能为空', '操作提示', function() {});
                return false;
            } else {
                var num = $('#SeaClue').val();
            }
            if (num != '') {
                $('#SeaCluetwo option').remove()
                var data = {
                    'firstSourceId': num
                };
                app.posttoken(app.url.api_base + "selections/second-sources", data,
                    function(req) {
                        if (req.code == 0) {
                            var data = req.data.sources;
                            if (data.length > 0) {
                                var html = '<option value="">请选择</option>';
                                $.each(data, function(i, v) {
                                    html += '<option value="' + v.id + '">' + v.text + '</option>'
                                });
                                $('#SeaCluetwo').html(html);

                            }
                        } else {
                            Prompt.show(req.message);
                        }
                    });
            }
        });

        //选择地区
        $(document).on('change', '#SeaCity', function() {
            $('#searegion option').remove();
            var num = $('#SeaCity').val();
            if (num != '') {
                var data = {
                    'cityCode': num
                };
                app.posttoken(app.url.api_base + "selections/districts", data,
                    function(req) {
                        if (req.code == 0) {
                            var data = req.data.districts;
                            if (data.length > 0) {
                                var html = '<option value="">请选择</option>';
                                $.each(data, function(i, v) {
                                    html += '<option value="' + v.id + '">' + v.text + '</option>'
                                });
                                $('#searegion').html(html);
                            }
                        } else {
                            Prompt.show(req.message);
                        }
                    });
            }
        });

        //选择分管
        $(document).on('change', 'input:radio[name="sea"] , #SeaCity, #searegion', function() {
            var data = {};
            var radio = $('input:radio[name="sea"]:checked').val();
            if (radio == 'LITERATURE') {
                data.subjectType = radio;
                $('.Seaclassbox').show();
                $('.SeaSubjectbox').hide();
            } else if (radio == 'ART') {
                data.subjectType = radio;
                $('.Seaclassbox').hide();
                $('.SeaSubjectbox').show();
            }
            data.cityCode = $('#SeaCity').val();
            data.districtCode = $('#searegion').val();
            if (data.subjectType != undefined && data.cityCode != null) {
                if (data.districtCode != null) {
                    app.posttoken(app.url.api_base + "selections/stores", data,
                        function(req) {
                            if (req.code == 0) {
                                var data = req.data.stores;
                                if (data.length > 0) {
                                    var html = '<option value="">请选择</option>';
                                    $.each(data, function(i, v) {
                                        html += '<option value="' + v.id + '">' + v.text + '</option>'
                                    });
                                    $('#SeaBranch').html(html);
                                }
                            } else {
                                Prompt.show(req.message);
                            }
                        });
                }
            }
        });

        //请求年级或者科目
        $(document).on('change', 'input:radio[name="sea"]', function() {
            var radio = $('input:radio[name="sea"]:checked').val();
            if (radio == 'LITERATURE') {
                app.posttoken(app.url.api_base + "selections/grades", {},
                    function(req) {
                        if (req.code == 0) {
                            var data = req.data.grades;
                            if (data.length > 0) {
                                var html = '<option value="">请选择</option>';
                                $.each(data, function(i, v) {
                                    html += '<option value="' + v.id + '">' + v.text + '</option>'
                                });
                                $('#Seaclass').html(html);
                            }
                        } else {
                            Prompt.show(req.message);
                        }
                    });
            } else if (radio == 'ART') {
                app.posttoken(app.url.api_base + "selections/subjects", {},
                    function(req) {
                        if (req.code == 0) {
                            var data = req.data.subjects;
                            if (data.length > 0) {
                                var html = '<option value="">请选择</option>';
                                $.each(data, function(i, v) {
                                    html += '<option value="' + v.id + '">' + v.text + '</option>'
                                });
                                $('#SeaSubject').html(html);
                            }
                        } else {
                            Prompt.show(req.message);
                        }
                    });
            }
        });

        //通过年级或者科目选择课程
        $(document).on('change', '#Seaclass,#SeaSubject', function() {
            var sval = $(this).val();
            var _this;
            var radio = $('input:radio[name="sea"]:checked').val();
            var data = {};
            if (radio == 'LITERATURE') {
                data.gradeId = sval;
                data.subjectType = 'LITERATURE';
            } else if (radio == 'ART') {
                data.subjectType = 'ART';
                data.subjectId = sval;
            }

            app.posttoken(app.url.api_base + "selections/courses", data,
                function(req) {
                    if (req.code == 0) {
                        var data = req.data.courses;
                        if (data.length > 0) {
                            var html = '<option value="">请选择</option>';
                            $.each(data, function(i, v) {
                                html += '<option value="' + v.id + '">' + v.text + '</option>'
                            });
                            $('#SeaCourse').html(html);
                        }
                    } else {
                        Prompt.show(req.message);
                    }
                });
        });

        //线索搜索提交
        $(document).on('click', '.btnsearch', function() {
            var SeaName = $('#SeaName').val();
            var SeaPhone = $('#SeaPhone').val();
            //电话号码
            var SeaAreacode = $('#SeaAreacode').val();
            var Seatelyphone = $('#Seatelyphone').val();

            if (SeaAreacode != '' && Seatelyphone != '') {
                var seatel = SeaAreacode + '-' + Seatelyphone;
            }
            var SeaAge = $('#SeaAge').val();
            var searchSEX = $('input:radio[name="searchSEX"]:checked').val();
            var dateStart = $('#date_start').val();
            var SeaOperator = $('#SeaOperator option:selected').attr('value');
            // var SeaRelationship = $('#SeaRelationship option:selected').attr('value');
            var SeaSchool = $('#SeaSchool').val();
            var SeaCity = $('#SeaCity option:selected').attr('value');
            var searegion = $('#searegion option:selected').attr('value');
            var SeaBusiness = $('input:radio[name="sea"]:checked').val();
            var SeaBranch = $('#SeaBranch option:selected').attr('value');
            var SeaSubject = $('#SeaSubject option:selected').attr('value');
            var Seaclass = $('#Seaclass option:selected').attr('value');
            var SeaCourse = $('#SeaCourse option:selected').attr('value');
            var SeaClue = $('#SeaClue option:selected').attr('value');
            var SeaCluetwo = $('#SeaCluetwo option:selected').attr('value');
            var dateNewstart = $('#date_Newstart').val();
            var SeaStatus = $('#SeaStatus option:selected').attr('value');
            var html = '<span>热搜词：</span>';
            if (SeaName != '') {
                html += '<span>' + SeaName + '</span>';
            }
            if (SeaPhone != '') {
                html += '<span>' + SeaPhone + '</span>';
            }
            if (seatel != undefined) {
                html += '<span>' + seatel + '</span>';
            }
            if (SeaAge != '') {
                html += '<span>' + SeaAge + '</span>';
            }
            if (searchSEX == 'MALE') {
                html += '<span>男</span>';
            } else if (searchSEX == 'FEMALE') {
                html += '<span>女</span>';
            }
            if (dateStart != '') {
                html += '<span>' + dateStart + '</span>';
            }
            if (SeaOperator != '' && SeaOperator != undefined) {

                html += '<span>' + $('#SeaOperator option:selected').html() + '</span>';
            }
            // if (SeaRelationship != '' && SeaRelationship != undefined) {
            //     html += '<span>' + $('#SeaRelationship option:selected').html() + '</span>';

            // }
            if (SeaCity != '' && SeaCity != undefined) {
                html += '<span>' + $('#SeaCity option:selected').html() + '</span>';
            }
            if (searegion != '' && searegion != undefined) {
                html += '<span>' + $('#searegion option:selected').html() + '</span>';
            }
            if (SeaBusiness == 'LITERATURE') {
                html += '<span> 国文</span>';
            } else if (SeaBusiness == 'ART') {
                html += '<span> 国艺</span>';
            }
            if (SeaBranch != '' && SeaBranch != undefined) {
                html += '<span>' + $('#SeaBranch option:selected').html() + '</span>';
            }
            if (SeaSubject != '' && SeaSubject != undefined) {
                html += '<span>' + $('#SeaSubject option:selected').html() + '</span>';
            }
            if (Seaclass != '' && Seaclass != undefined) {
                html += '<span>' + $('#Seaclass option:selected').html() + '</span>';
            }
            if (SeaCourse != '' && SeaCourse != undefined) {
                html += '<span>' + $('#SeaCourse option:selected').html() + '</span>';
            }
            if (SeaClue != '' && SeaClue != undefined) {
                html += '<span>' + $('#SeaClue option:selected').html() + '</span>';
            }
            if (SeaCluetwo != '' && SeaCluetwo != undefined) {
                html += '<span>' + $('#SeaCluetwo option:selected').html() + '</span>';
            }
            if (dateNewstart != '') {
                html += '<span>' + dateNewstart + '</span>';
            }
            if (SeaStatus != '' && SeaStatus != undefined) {
                html += '<span>' + $('#SeaStatus option:selected').html() + '</span>';
            }
            _this.data.name = SeaName;
            _this.data.mobile = SeaPhone;
            _this.data.telePhone = seatel;
            _this.data.age = SeaAge;
            _this.data.lastUpdateTime = dateNewstart;
            _this.data.status = SeaStatus;
            if (searchSEX == undefined) {
                _this.data.gender = '';
            } else {
                _this.data.gender = searchSEX;
            }
            _this.data.createDate = dateStart;
            _this.data.creatorId = SeaOperator;
            // _this.data.relationshipType = SeaCity;
            _this.data.cityCode = SeaCity;
            _this.data.districtCode = searegion;
            if (SeaBusiness == undefined) {
                _this.data.subjectType = '';
            } else {
                _this.data.subjectType = SeaBusiness;
            }
            _this.data.subjectId = SeaSubject;
            _this.data.gradeId = Seaclass;
            _this.data.storeId = SeaBranch;
            _this.data.courseId = SeaCourse;
            _this.data.childSourceId = SeaCluetwo;
            _this.data.sourceId = SeaClue;
            _this.data.pageIndex = 1;
            _this.data.everyPage = 10;
            if (app.getItem('role') == 'TMKManager' || app.getItem('role') == 'MarketManager') {
                _this.data.owner = false;
            } else {
                _this.data.owner = true;
            }
            $('.searchCriteria').html(html)
            if ($('.searchCriteria').find('span').length > 1) {
                $('#pageToolbar,.table').hide();
                var type = $('.Administrationtab .active').attr('itype');
                adddata(_this.data, type);
            } else {
                Prompt.show("搜索条件为空！", '操作提示', function() {});
                return false;
            }

        });

        //重置搜索条件
        $(document).on('click', '.iRefresh', function() {
            _this.data.name = '';
            _this.data.mobile = '';
            _this.data.age = '';
            _this.data.gender = '';
            _this.data.createDate = '';
            _this.data.creatorId = '';
            _this.data.relationshipType = '';
            _this.data.cityCode = '';
            _this.data.districtCode = '';
            _this.data.subjectType = '';
            _this.data.subjectId = '';
            _this.data.gradeId = '';
            _this.data.storeId = '';
            _this.data.courseId = '';
            _this.data.childSourceId = '';
            _this.data.sourceId = '';
            _this.data.status = '';
            _this.data.lastUpdateTime = '';
            $('#pageToolbar,.table').hide();
            var type = $('.Administrationtab .active').attr('itype');
            adddata(_this.data, type);
            $('.searchCriteria').html('<span>热搜词：</span>')

        });

        //添加的弹框
        $(document).on('click', '.IAdd', function() {
            AddInitData();
            getNumber();
        });

        //无效名单
        $(document).on('click', '.addBtninvalid', function() {
            var data = {
                'potentialId': $('#addClue').attr('potent'),
            }
            app.posttoken(app.url.api_base + "leads/promotion-potential-unvalid", data, function(req) {
                if (req.code == 0) {
                    $('#addClue').modal('hide');
                    Prompt.show('名单无效标记成功!', '操作提示', function() {
                        AddInitData();

                    });
                }
            }, true)
        })

        //再联系
        $(document).on('click', '.addBtnAgain', function() {
            var data = {
                'potentialId': $('#addClue').attr('potent'),
            }
            app.posttoken(app.url.api_base + "leads/promotion-potential-recontact", data, function(req) {
                if (req.code == 0) {
                    $('#addClue').modal('hide');
                    Prompt.show('名单再联系标记成功!', '操作提示', function() {
                        AddInitData();
                    });
                }
            }, true)
        })

        //验证手机号码
        $(document).on('focusout', '#AddIphone', function() {
            var filter = /^1\d{10}$/; //手机号
            var phone = $('#AddIphone').val();
            if (phone != '') {
                if (filter.test(phone) == false) {
                    Prompt.show("手机号格式错误", '操作提示', function() {});
                    return false;
                } else {
                    var data = {
                        mobile: phone,
                    }
                    //编辑手机的号码
                    if ($('#addClue').attr('dataid') != undefined) {
                        data.id = $('#addClue').attr('dataid');
                    }
                    app.posttoken(app.url.api_base + "leads/get-lead-by-mobile", data,
                        function(req) {
                            if (req.code == 0) {
                                Prompt.show('该手机号已被其它线索使用！', '操作提示', function() {
                                    $('#AddIphone').val('');
                                    $("#AddIphone").attr("readOnly", false);
                                });
                            }
                        });
                }
            }
        });

        //验证电话号码
        $(document).on('focusout', '#AddAreacode,#Addtelyphone', function() {
            var AddAreacode = $('#AddAreacode').val();
            var Addtelyphone = $('#Addtelyphone').val();
            if (AddAreacode != '' && Addtelyphone != '') {
                if (Addtelyphone.length < 5) {
                    Prompt.show("请输入有效的电话号", '操作提示', function() {});
                    return false;
                }
                if (AddAreacode == '') {
                    Prompt.show("请输入区号(如上海：021)", '操作提示', function() {});
                    return false;
                } else {
                    if (AddAreacode.length < 3) {
                        Prompt.show("请输入有效的区号", '操作提示', function() {});
                        return false;
                    }
                }
                var tel = AddAreacode + '-' + Addtelyphone;
                var data = {
                    'telePhone': tel,
                }
                //编辑手机的号码
                if ($('#addClue').attr('dataid') != undefined) {
                    data.id = $('#addClue').attr('dataid');
                }
                app.posttoken(app.url.api_base + "leads/get-lead-by-mobile", data,
                    function(req) {
                        if (req.code == 1) {} else {
                            Prompt.show('该电话号码已被其它线索使用！', '操作提示', function() {
                                $('#AddAreacode,#Addtelyphone,#AddLandline').val('');
                            });
                        }
                    });


            }
        })

        //选择地区
        $(document).on('change', '#AddCity', function() {
            $('#Addregion option').remove()
            var num = $('#AddCity').val();
            if (num != '') {
                var data = {
                    'cityCode': num
                };
                app.posttoken(app.url.api_base + "selections/districts", data,
                    function(req) {
                        if (req.code == 0) {
                            var data = req.data.districts;
                            if (data.length > 0) {
                                var html = '<option value="">请选择</option>';
                                $.each(data, function(i, v) {
                                    html += '<option value="' + v.id + '">' + v.text + '</option>'
                                });
                                $('#Addregion').html(html);

                            }
                        } else {
                            Prompt.show(req.message);
                        }
                    });
            }
        });

        //判断选择地区的时候是否选择城市
        $(document).on('click', '#Addregion', function() {
            if ($(this).find('option').length <= 1) {
                Prompt.show("城市不能为空", '操作提示', function() {});
                return false;
            }
        });

        //判断选择二级线索来源的时候是否已选择一级
        $(document).on('click', '#AddSourcetwo', function() {
            if ($(this).find('option').length < 1) {
                Prompt.show("线索一级来源不能为空", '操作提示', function() {});
                return false;
            }
        });

        //选择二级线索来源

        $(document).on('change', '#AddSource', function() {
            $('#AddSourcetwo option').remove()
            if ($('#AddSource').val() == '请选择') {
                Prompt.show('数据不能为空', '操作提示', function() {});
                return false;
            } else {

                var num = $('#AddSource').val();
            }
            if (num != '') {
                var data = {
                    'firstSourceId': num
                };
                app.posttoken(app.url.api_base + "selections/second-sources", data,
                    function(req) {
                        if (req.code == 0) {
                            var data = req.data.sources;
                            if (data.length > 0) {
                                var html = '<option value="">请选择</option>';
                                $.each(data, function(i, v) {
                                    html += '<option value="' + v.id + '">' + v.text + '</option>'
                                });
                                $('#AddSourcetwo').html(html);

                            }
                        } else {
                            Prompt.show(req.message);
                        }
                    });
            }
        });

        //选择分管
        $(document).on('change', 'input:radio[name="shiye"] , #AddCity, #Addregion', function() {
            $('#AddCourse option').remove();
            var data = {};
            var radio = $('input:radio[name="shiye"]:checked').val();
            if (radio == 'LITERATURE') {
                data.subjectType = radio;
                $('.Iaddclass').show();
                $('.Iaddsubiet').hide();
            } else if (radio == 'ART') {
                data.subjectType = radio;
                $('.Iaddclass').hide();
                $('.Iaddsubiet').show();
            }
            data.cityCode = $('#AddCity').val();
            data.districtCode = $('#Addregion').val();
            if (data.subjectType != undefined) {
                if (data.cityCode != '') {
                    if (data.districtCode != null && data.districtCode != '') {
                        app.posttoken(app.url.api_base + "selections/stores", data,
                            function(req) {
                                if (req.code == 0) {
                                    var data = req.data.stores;
                                    if (data.length > 0) {
                                        var html = '<option value="">请选择</option>';
                                        $.each(data, function(i, v) {
                                            html += '<option value="' + v.id + '">' + v.text + '</option>'
                                        });
                                        $('#AddBranch').html(html);
                                    } else {
                                        $('#AddBranch').html('<option value="">请选择</option>')
                                    }
                                } else {
                                    Prompt.show(req.message);
                                }
                            });
                    }
                }
            }
        });

        //请求年级或者科目
        $(document).on('change', 'input:radio[name="shiye"]', function() {
            loadcourseorclass();
        });

        //通过年级或者科目选择课程
        $(document).on('change', '#AddClass,#AddSubject', function() {
            $('#AddCourse option').remove()
            var sval = $(this).val();
            var _this;
            var radio = $('input:radio[name="shiye"]:checked').val();
            var data = {};
            if (radio == 'LITERATURE') {
                data.gradeId = sval;
                data.subjectType = 'LITERATURE';
                // _this=$('#AddClass');
            } else if (radio == 'ART') {
                data.subjectType = 'ART';
                data.subjectId = sval;
                // _this=$('#AddSubject');
            }

            app.posttoken(app.url.api_base + "selections/courses", data,
                function(req) {
                    if (req.code == 0) {
                        var data = req.data.courses;
                        if (data.length > 0) {
                            var html = '';
                            // var html = '<option value="">请选择</option>';
                            $.each(data, function(i, v) {
                                if (i == 0) {
                                    html += '<option value="' + v.id + '" selected = "selected">' + v.text + '</option>'
                                } else {
                                    html += '<option value="' + v.id + '" >' + v.text + '</option>'
                                }
                            });

                            $('#AddCourse').html(html);
                        }
                    } else {
                        Prompt.show(req.message);
                    }
                });
        });

        //线索添加提交或编辑  保存并新建 
        $(document).on('click', '#addClue .addClue', function() {
            var data = yanzheng();
            console.log('add new ');
            if (data != '') {
                if ($('#addClue').attr('dataid') != undefined) {
                    console.log(data)
                    data.id = $('#addClue').attr('dataid');
                    app.posttoken(app.url.api_base + "leads/edit", data,
                        function(req) {
                            if (req.code == 0) {
                                Prompt.show(req.message);
                                $('#addClue').removeAttr('dataid');
                                $('#addClue').modal('hide');
                                var type = $('.Administrationtab .active').attr('itype');
                                adddata(_this.data, type);
                            } else {
                                Prompt.show(req.message);
                            }
                        });
                } else { //添加
                    data.createType = 'create';
                    if ($('#addClue').attr('potent') != undefined) {
                        data.potentialId = $('#addClue').attr('potent');

                    }
                    app.posttoken(app.url.api_base + "leads/create", data,
                        function(req) {
                            if (req.code == 0) {
                                $('#addClue').modal('hide');
                                Prompt.show(req.message, '操作提示', function() {
                                    AddInitData();
                                });
                                $('.addBtninvalid,.addBtnAgain').hide();
                                // $('#addClue').modal('show');
                                // $('#addClue').removeAttr('dataid');
                                // $('#addClue').find('input:text').val('');
                                // // $("#AddRelationship").get(0).selectedIndex = 0;
                                // $('#AddCity').get(0).selectedIndex = 0;
                                // $('#Addregion option').remove();
                                // $('#AddBranch option').remove();
                                // $('#AddSubject option').remove();
                                // $('#AddClass option').remove();
                                // $('#AddCourse option').remove();
                                // $('#AddSourcetwo option').remove();
                                // $('#AddSource').get(0).selectedIndex = 0;
                                // $('#AddSourcetwo').get(0).selectedIndex = 0;
                                // $('input:radio[name="shiye"]').attr('checked', false);
                                // $('.addcourse span').removeClass('active');
                                // $('#AddAddress,#AddRemarks').val('');

                                // //获取城市
                                // app.posttoken(app.url.api_base + "selections/citys", {},
                                //     function(req) {
                                //         if (req.code == 0) {
                                //             var data = req.data.citys;
                                //             if (data.length > 0) {
                                //                 var html = '<option value="">请选择</option>';
                                //                 $.each(data, function(i, v) {
                                //                     html += '<option value="' + v.id + '">' + v.text + '</option>'
                                //                 });
                                //                 $('#AddCity').html(html);
                                //             }
                                //         } else {
                                //             Prompt.show(req.message);
                                //         }
                                //     });
                                //线索来源
                                // app.posttoken(app.url.api_base + "selections/sources", {},
                                //     function(req) {
                                //         if (req.code == 0) {
                                //             var data = req.data.sources;
                                //             if (data.length > 0) {
                                //                 var html = '<option value="">请选择</option>';
                                //                 $.each(data, function(i, v) {
                                //                     html += '<option value="' + v.id + '">' + v.text + '</option>'
                                //                 });
                                //                 $('#AddSource').html(html);
                                //             }
                                //         } else {
                                //             Prompt.show(req.message);
                                //         }
                                //     });


                            } else {
                                Prompt.show(req.message);
                            }
                        });
                }
            }
        });

        //保存并提交
        $(document).on('click', '#addClue .addsubmint', function() {
            var data = yanzheng();
            if (data != '') {
                console.log(data)
                data.createType = 'submit';
                app.posttoken(app.url.api_base + "leads/create", data,
                    function(req) {
                        if (req.code == 0) {
                            Prompt.show(req.message);
                            $('#addClue').modal('hide');
                            app.go('index.html?itype=0');

                        } else {
                            Prompt.show(req.message);
                        }
                    });
            }
        })
      
        //提交并新建
        $(document).on('click', '#addClue .addsubmintNew', function() {
            var data = yanzheng();
            if (data != '') {
                console.log(data)
                data.createType = 'submit';
                data.potentialId=$('#addClue').attr('potent');
                app.posttoken(app.url.api_base + "leads/create", data,
                    function(req) {
                        if (req.code == 0) {
                            $('#addClue').modal('hide');
                            Prompt.show(req.message, '操作提示', function() {
                             AddInitData();
                            
                            });
                            $('.addBtninvalid,.addBtnAgain').hide();
                        } else {
                            Prompt.show(req.message);
                        }
                    });
            }
        })

        //线索修改查看
        $(document).on('click', '.modify', function() {
            var num = $(this).parents('tr').attr('id');
            var data = {
                'leadId': num
            };

            $('#addClue').removeAttr('dataid');
            $('#addClue').find('input:text').val('');

            // $("#AddRelationship").get(0).selectedIndex = 0;
            //弹框显示 清空数据
            $('#AddCity option').remove();
            $('#Addregion option').remove();
            $('#AddBranch option').remove();
            $('#AddSubject option').remove();
            $('#AddClass option').remove();
            $('#AddCourse option').remove();
            $('#AddSource option').remove();
            $('#AddSourcetwo option').remove();
            $('input:radio[name="shiye"]').attr('checked', false);
            $('input:radio[name="addSEX"]').attr('checked', false);
            $('.addcourse span').removeClass('active');
            $('#AddAddress,#AddRemarks,#AddLandline,#AddAreacode,#Addtelyphone').val('');

            $('.addsubmint').hide();
            $('.addcencal').show();
            $('#addClue .addClue').html('保存编辑');
            $('#addClue .addClue').show();
            $('#addClue .addsubmintNew').hide();
            $('#addClue h4').html('编辑线索');
            $('#AddLandline').val('');
            $('.addBtninvalid,.addBtnAgain').hide();
            app.posttoken(app.url.api_base + "leads/detail", data,
                function(req) {
                    if (req.code == 0) {
                        var data = req.data.leadResponse;
                        $('#addClue').attr('dataid', data.id)
                        $('#AddName').val(data.name)
                        $('#AddStuName').val(data.studentName);
                        $('#AddEmail').val(data.email)
                        $('#AddSchool').val(data.schoolName)
                        $('#AddRemarks').val(data.note)
                        $('#AddAddress').val(data.address)
                        if (data.age > 0) {
                            $('#AddAge').val(data.age)
                        }
                        $('#AddIphone').val(data.mobile);

                        var dataphone = data.telePhone.split("-");
                        $('#AddAreacode').val(dataphone[0]); //地区号
                        $('#Addtelyphone').val(dataphone[1]); //电话号
                        if (dataphone.length == 3) {
                            $('#AddLandline').val(dataphone[2]); //座机号
                        }


                        if (data.gender == 'FEMALE') {
                            $("input[name='addSEX'][value='MALE']").removeAttr("checked")
                            $("input[name='addSEX'][value='FEMALE']").prop("checked", true)
                        } else if (data.gender == 'MALE') {
                            $("input[name='addSEX'][value='FEMALE']").removeAttr("checked")
                            $("input[name='addSEX'][value='MALE']").prop("checked", true)
                        }
                        if (data.subjectType == 'ART') {
                            $("input[name='shiye'][value='LITERATURE']").removeAttr("checked")
                            $("input[name='shiye'][value='ART']").prop("checked", true)
                        } else if (data.subjectType == 'LITERATURE') {
                            $("input[name='shiye'][value='ART']").removeAttr("checked")
                            $("input[name='shiye'][value='LITERATURE']").prop("checked", true)
                        }
                        $("input[name='shiye'][value='" + data.subjectType + "']").attr("checked", true)
                        // $('#AddRelationship').val(data.relationshipType)
                        var city = '<option>请选择</option>'
                        $.each(data.citys, function(i, v) {
                            if (data.cityCode == v.id) {
                                city += '<option value="' + v.id + '" selected = "selected" >' + v.text + '</option>'
                            } else {
                                city += '<option value="' + v.id + '">' + v.text + '</option>'
                            }
                        })
                        $('#AddCity').html(city);
                        var region = '<option>请选择</option>'
                        $.each(data.districts, function(i, v) {
                            if (data.districtCode == v.id) {
                                region += '<option value="' + v.id + '" selected = "selected" >' + v.text + '</option>'
                            } else {
                                region += '<option value="' + v.id + '">' + v.text + '</option>'
                            }
                        })
                        $('#Addregion').html(region);
                        var AddBranch = '<option>请选择</option>'
                        $.each(data.stores, function(i, v) {
                            if (data.storeId == v.id) {
                                AddBranch += '<option value="' + v.id + '" selected = "selected" >' + v.text + '</option>'
                            } else {
                                AddBranch += '<option value="' + v.id + '">' + v.text + '</option>'
                            }
                        })
                        $('#AddBranch').html(AddBranch);
                        var AddSource = '<option>请选择</option>'
                        console.log(data.sources)
                        $.each(data.sources, function(i, v) {
                            if (data.sourceId == v.id) {
                                AddSource += '<option value="' + v.id + '" selected = "selected" >' + v.text + '</option>'
                            } else {
                                AddSource += '<option value="' + v.id + '">' + v.text + '</option>'
                            }
                        })
                        $('#AddSource').html(AddSource);

                        var AddSourcetwo = '<option>请选择</option>'
                        $.each(data.childSources, function(i, v) {
                            if (data.childSourceId == v.id) {
                                AddSourcetwo += '<option value="' + v.id + '" selected = "selected" >' + data.childSourceName + '</option>'
                            } else {
                                AddSourcetwo += '<option value="' + v.id + '">' + v.text + '</option>'
                            }
                        })
                        $('#AddSourcetwo').html(AddSourcetwo);

                        var AddCourse = '<option>请选择</option>'
                        $.each(data.courses, function(i, v) {
                            if (data.courseId == v.id) {
                                AddCourse += '<option value="' + v.id + '" selected = "selected" >' + v.text + '</option>'
                            } else {
                                AddCourse += '<option value="' + v.id + '">' + v.text + '</option>'
                            }
                        })
                        $('#AddCourse').html(AddCourse);

                        if (data.subjectType == 'LITERATURE') {
                            $('.Iaddclass').show()
                            var AddClass = '<option>请选择</option>'
                            $.each(data.grades, function(i, v) {
                                if (data.gradeId == v.id) {
                                    AddClass += '<option value="' + v.id + '" selected = "selected" >' + v.text + '</option>'
                                } else {
                                    AddClass += '<option value="' + v.id + '">' + v.text + '</option>'
                                }
                            })
                            $('#AddClass').html(AddClass);

                        } else {
                            $('.Iaddsubiet').show()
                            var AddSubject = '<option>请选择</option>'
                            $.each(data.subjects, function(i, v) {
                                if (data.subjectId == v.id) {
                                    AddSubject += '<option value="' + v.id + '" selected = "selected" >' + v.text + '</option>'
                                } else {
                                    AddSubject += '<option value="' + v.id + '">' + v.text + '</option>'
                                }
                            })
                            $('#AddSubject').html(AddSubject);
                        }
                        var addcourse = ''
                        $.each(data.interestPoints, function(i, v) {
                            if (data.interestPointIds.length > 0) {
                                for (var y = 0; y < data.interestPointIds.length; y++) {
                                    console.log(data.interestPointIds[y] + '|' + v.id)
                                    if (data.interestPointIds[y] == v.id) {
                                        addcourse += '<li><span id="' + v.id + '" class="active">' + v.text + '</span></li>';
                                        return true;
                                    } else {
                                        if (y == data.interestPointIds.length - 1) {
                                            addcourse += '<li><span id="' + v.id + '">' + v.text + '</span></li>';
                                        }
                                    }
                                }
                            } else {
                                addcourse += '<li><span id="' + v.id + '">' + v.text + '</span></li>';
                            }

                        })
                        $('.addcourse').html(addcourse);

                    } else {
                        Prompt.show(req.message);
                    }
                });
        });

        //单独查看详情
        $(document).on('click', '.tablebox tbody img', function() {
            $('.SeeSchool,.SeeAddress,.SeeNote,.SeeOther,.SeeEmail,.SeeAge,.SeeSex,.SeeStuName').html('');
            var num = $(this).parents('tr').attr('id');
            var data = {
                'leadId': num
            }
            app.posttoken(app.url.api_base + "leads/detail", data,
                function(req) {
                    if (req.code == 0) {
                        var data = req.data.leadResponse;

                        if (app.getItem('role') == 'TMKManager' || app.getItem('role') == 'MarketManager') {
                            if ($('.Administrationtab .active').attr('itype') == 2 || $('.Administrationtab .active').attr('itype') == 0) {

                                if (data.leadHistorys.length > 0) {

                                    addgenjin(data.leadHistorys);
                                    //判断状态
                                    if (app.getParameterByName('itype') == 0) {
                                        $('.AddTable thead , .addClear, .itypeshow').hide();
                                        $('.btnsubmit').show();

                                    } else {
                                        $('.AddTable thead ,.addClear,.itypeshow').show();
                                        $('.btnsubmit').hide();
                                    }
                                    // $('#ClueDetail .btnsubmit').hide()
                                    // $('#ClueDetail .addClear').show()
                                    $('.againfp h4').html('线索跟进记录')
                                    $('.againfp').show();

                                } else {
                                    $('.againfp h4').html('暂无线索跟进记录')
                                    $('#ClueDetail .addClear').hide()
                                    $('#ClueDetail .AddTable').hide()
                                }
                            } else {
                                $('#ClueDetail .btn-primary').show();
                                $('#ClueDetail .addClear').hide();
                                $('.againfp').hide();
                            }
                        }
                        $('#ClueDetail').attr('dataid', data.id)
                        $('.SeeStatus').html(data.leadPeriodName)
                        $('.SeeStuName').html(data.studentName)
                        $('.SeeTime').html(data.createTime)
                        $('.SeeCaozuo').html(data.staffName)
                        $('.SeeKemu').html(data.course);
                        // if(data.subjectId==0){
                        //     $('.Titkemu').html('课 程：')
                        // }else{
                        //     $('.SeeKemu').html(data.course)
                        //      $('.Titkemu').html('课 程：')
                        // }
                        
                        $('.Seelaiyuan').html(data.childSourceName)
                        $('.SeeOther').html(data.interestPointName)
                        $('.SeeNote').html(data.note)
                        $('.SeeName').html(data.name)
                        if (data.mobile != '') {
                            $('.SeePhone').html(data.mobile)
                            if (data.telePhone != '') {
                                $('.Seetel').html(data.telePhone)
                                $('.Detaphone').show();
                            } else {
                                $('.Detaphone').hide();
                            }
                        } else {
                            $('.SeePhone').html(data.telePhone);
                            $('.Detaphone').hide();
                        }
                        if (data.age != 0) {
                            $('.SeeAge').html(data.year + ' 年 01 月 01 日')
                        }
                        $('.SeeSex').html(data.genderName)
                        // $('.Seeguanxi').html(data.relationshipTypeName)
                        $('.SeeEmail').html(data.email)
                        $('.SeeSchool').html(data.schoolName)
                        $('.SeeAddress').html(data.address)
                    } else {
                        Prompt.show(req.message);
                    }
                });
        });

        //删除
        $(document).on('click', '.del', function() {
            var num = $(this).parents('tr').attr('id');
            $('#SingleEel').attr('delid', num);
            $('#SingleEel').modal('show')
        });

        //批量删除
        $(document).on('click', '.allediterdel', function() {
            var num = sectionId();
            if (num == '') {
                Prompt.show('请选择要批量删除的数据!', '操作提示', function() {});
                return false;
            } else {
                if (num.length > 0) {
                    var numarray = num.split(',');
                    var newnum = new Array();
                    var de = 0;
                    $.each(numarray, function(i, v) {
                        if ($('.table #' + v).find('.del').length == 1) {
                            newnum.push(v);
                        } else if ($('.table #' + v).find('.del').length == 0) {
                            de = 1;
                        }
                    });
                    if (de == 1) {
                        Prompt.show('您所选中的线索部分不支持删除，我们将为您过滤掉不支持的信息，是否继续删除？', '警告提示', function() {
                            var data = {
                                'leadId': newnum.toString(),
                            };
                            app.posttoken(app.url.api_base + "leads/delete", data,
                                function(req) { //撤回成功状态1
                                    if (req.code == 1) {
                                        Prompt.show('删除成功!', '操作提示', function() {});
                                        $('#pageToolbar,.table').hide();
                                        var type = $('.Administrationtab .active').attr('itype');
                                        adddata(_this.data, type);
                                    } else {
                                        Prompt.show(req.message, '操作提示', function() {});
                                    }
                                });
                        }, function() {})
                    } else {
                        $('#SingleEel').attr('delid', num);
                        $('#SingleEel h5').html('您确定要批量删除选中线索?');
                        $('#SingleEel').modal('show');
                    }
                }

            }
        });

        //提交删除
        $(document).on('click', '#SingleEel .btn-primary', function() {
            var data = {
                'leadId': $('#SingleEel').attr('delid')
            }
            app.posttoken(app.url.api_base + "leads/delete", data,
                function(req) {
                    if (req.code == 0) {
                        Prompt.show('删除成功!');
                        $('#pageToolbar,.table').hide();
                        var type = $('.Administrationtab .active').attr('itype')
                        adddata(_this.data, type);
                    } else {
                        Prompt.show(req.message);
                    }
                });
        });

        //提交线索
        $(document).on('click', '.Submit', function() {
            var num = $(this).parents('tr').attr('id');
            $('#SingleCommit').attr('delid', num);
            $('#SingleCommit').modal('show');
        });

        //批量提交
        $(document).on('click', '.allSubmit', function() {
            var num = sectionId();
            if (num == '') {
                Prompt.show('请选择要批量提交的线索!', '操作提示', function() {});
                return false;
            } else {
                $('#SingleCommit').attr('delid', num);
                $('#SingleCommit h5').html('您确定要批量提交选中线索?');
                $('#SingleCommit').modal('show');
            }
        });

        //提交线索成功
        $(document).on('click', '#SingleCommit .btn-primary', function() {
            var data = {
                'leadId': $('#SingleCommit').attr('delid')
            }
            app.posttoken(app.url.api_base + "leads/submit", data,
                function(req) {
                    if (req.code == 0) {
                        Prompt.show('提交成功!');
                        $('#pageToolbar,.table').hide();
                        var type = $('.Administrationtab .active').attr('itype');
                        // console.log(_this);
                        adddata(_this.data, type);
                    } else {
                        Prompt.show(req.message);
                    }
                });
        });

        //撤回
        $(document).on('click', '.withdraw', function() {
            var num = $(this).parents('tr').attr('id');
            $('#Withdraw').attr('delid', num);
            $('#Withdraw').modal('show');
        });

        //批量撤回
        $(document).on('click', '.allediterback', function() {
            var num = sectionId();
            if (num == '') {
                Prompt.show('请选择要批量撤回的线索!', '操作提示', function() {});
                return false;
            } else {
                if (num.length > 0) {
                    var numarray = num.split(',');
                    var newnum = new Array();
                    var de = 0;
                    $.each(numarray, function(i, v) {
                        if ($('.table #' + v).find('.withdraw').length == 1) {
                            newnum.push(v);
                        } else if ($('.table #' + v).find('.withdraw').length == 0) {
                            de = 1;
                        }
                    });
                    if (de == 1) {
                        Prompt.show('您所选中的线索部分不支持撤回，我们将为您过滤掉不支持的信息，是否继续撤回？', '警告提示', function() {
                            var data = {
                                'leadId': newnum.toString(),
                            };
                            app.posttoken(app.url.api_base + "leads/cancel", data,
                                function(req) { //撤回成功状态1
                                    if (req.code == 1) {
                                        Prompt.show('撤回成功!', '操作提示', function() {});
                                        $('#pageToolbar,.table').hide();
                                        var type = $('.Administrationtab .active').attr('itype');
                                        adddata(_this.data, type);
                                    } else {
                                        Prompt.show(req.message, '操作提示', function() {});
                                    }
                                });

                        }, function() {})
                    } else {
                        $('#Withdraw').attr('delid', num);
                        $('#Withdraw h4').html('您确定要批量撤回选中线索?');
                        $('#Withdraw').modal('show');
                    }
                }
            }
        });

        //撤回订单成功
        $(document).on('click', '#Withdraw .btn-primary', function() {
            var data = {
                'leadId': $('#Withdraw').attr('delid')
            }
            app.posttoken(app.url.api_base + "leads/cancel", data,
                function(req) { //撤回成功状态1
                    if (req.code == 0) {
                        $('#pageToolbar,.table').hide();
                        var type = $('.Administrationtab .active').attr('itype');
                        adddata(_this.data, type);
                        Prompt.show('撤回成功!');
                    } else {
                        Prompt.show(req.message);
                    }
                });
        });

        //管理者 线索审核
        $(document).on('click', '.Trial', function() {
            var num = $(this).parents('tr').attr('id');
            $('#Toexamine').attr('delid', num);
            $('#Toexamine').modal('show');
        });

        //管理者 批量线索审核
        $(document).on('click', '.allTrial', function() {
            var num = sectionId();
            if (num == '') {
                Prompt.show('请选择要批量审核的线索!', '操作提示', function() {});
                return false;
            } else {
                $('#Toexamine').attr('delid', num);
                $('#Toexamine').modal('show');
            }
        });

        //管理者 审批提交
        $(document).on('click', '#Toexamine .btn-primary', function() {
            var bool = $('input[name="Clue"]:checked').val();
            if (bool == undefined) {
                Prompt.show('请选择线索审核结果!', '操作提示', function() {});
                return false;
            }
            var data = {
                'leadId': $('#Toexamine').attr('delid'),
                'pass': bool,
            }
            app.posttoken(app.url.api_base + "leads/audit", data,
                function(req) {
                    if (req.code == 0) {
                        Prompt.show('审核成功!');
                        $('#pageToolbar,.table').hide();
                        $('#Toexamine').modal('hide');
                        var type = $('.Administrationtab .active').attr('itype');
                        adddata(_this.data, type);
                    } else {
                        Prompt.show(req.message);
                    }
                });
        });

        //管理者 线索再分配
        $(document).on('click', '.distribution', function() {
            $('#myCity option').remove();
            $('#Myregion option').remove();
            $('#MyBranch option').remove();
            $('input:radio[name="BusinessUnit"]').attr('checked', false);

            var num = $(this).parents('tr').attr('id');
            $('#myModal').attr('delid', num);
            $('#myModal').modal('show');
            //获取城市
            app.posttoken(app.url.api_base + "selections/citys", {},
                function(req) {
                    if (req.code == 0) {
                        var data = req.data.citys;
                        if (data.length > 0) {
                            var html = '<option value="">请选择</option>';
                            $.each(data, function(i, v) {
                                html += '<option value="' + v.id + '">' + v.text + '</option>'
                            });
                            $('#myCity').html(html);
                        }
                    } else {
                        Prompt.show(req.message);
                    }
                });
        });

        //选择地区
        $(document).on('change', '#myCity', function() {
            $('#Myregion option').remove()
            $('#MyBranch option').remove();
            var num = $('#myCity').val();
            if (num != '') {
                var data = {
                    'cityCode': num
                };
                app.posttoken(app.url.api_base + "selections/districts", data,
                    function(req) {
                        if (req.code == 0) {
                            var data = req.data.districts;
                            if (data.length > 0) {
                                var html = '<option value="">请选择</option>';
                                $.each(data, function(i, v) {
                                    html += '<option value="' + v.id + '">' + v.text + '</option>'
                                });
                                $('#Myregion').html(html);
                            }
                        } else {
                            Prompt.show(req.message);
                        }
                    });
            }
        });

        //判断选择地区的时候是否选择城市
        $(document).on('click', '#Myregion', function() {
            if ($(this).find('option').length <= 1) {
                Prompt.show("城市不能为空", '操作提示', function() {});
                return false;
            }
        });

        //选择分管
        $(document).on('change', 'input:radio[name="BusinessUnit"] , #myCity, #Myregion', function() {
            $('#MyBranch option').remove();
            var data = {};
            var radio = $('input:radio[name="BusinessUnit"]:checked').val();
            data.subjectType = radio;
            data.cityCode = $('#myCity').val();
            data.districtCode = $('#Myregion').val();
            if (data.subjectType != undefined && data.cityCode != null) {
                if (data.districtCode != null) {
                    app.posttoken(app.url.api_base + "selections/stores", data,
                        function(req) {
                            if (req.code == 0) {
                                var data = req.data.stores;
                                if (data.length > 0) {
                                    var html = '<option value="">请选择</option>';
                                    $.each(data, function(i, v) {
                                        html += '<option value="' + v.id + '">' + v.text + '</option>'
                                    });
                                    $('#MyBranch').html(html);
                                } else {
                                    Prompt.show('该地区暂无相关分馆!', '操作提示', function() {});
                                    return false;
                                }
                            } else {
                                Prompt.show(req.message);
                            }
                        });
                }
            }
        });

        //管理者 批量线索再分配
        $(document).on('click', '.alldistribution', function() {
            var num = sectionId();
            if (num == '') {
                Prompt.show('请选择要批量审核的线索!', '操作提示', function() {});
                return false;
            } else {
                $('#myModal').attr('delid', num);
                $('#myModal').modal('show');
            }
        });

        //管理者 再分配提交
        $(document).on('click', '#myModal .btn-primary', function() {
            var store = 1;
            if ($('#MyBranch').val() == undefined) {
                Prompt.show('请选择分馆');
                return false;
            }
            if ($('#MyBranch').val() == '') {
                Prompt.show('请选择分馆');
                return false;
            }

            var data = {
                'leadId': $('#myModal').attr('delid'),
                'storeId': $('#MyBranch').val(),
            }
            if ($('#MyBranch').val() != '') {
                app.posttoken(app.url.api_base + "leads/reassign", data,
                    function(req) { //撤回成功状态1
                        if (req.code == 0) {
                            Prompt.show('再分配提交成功!');
                            $('#pageToolbar,.table').hide();
                            var type = $('.Administrationtab .active').attr('itype');
                            adddata(_this.data, type);
                        } else {
                            Prompt.show(req.message);
                        }
                        $('#myModal').modal('hide');
                    });
            }
        });
        //线索再分配单个或者多个删除
        $(document).on('click', '.AddTable .Adddelall,.AddTable .adddel', function() {
            if ($(this).attr('class') == 'Adddelall') {
                //全选
                var stringid = seesectionId();
                if (stringid.length > 0) {
                    var data = {
                        'leadHistoryId': stringid
                    }
                } else {
                    Prompt.show('请选择要操作的数据！');
                    return false;
                }
            } else if ($(this).attr('class') == 'adddel') {
                var data = {
                    'leadHistoryId': $(this).attr('id')
                }
            }
            app.posttoken(app.url.api_base + "leads/refresh-historys", data,
                function(req) {
                    if (req.code == 0) {
                        Prompt.show('线索跟进记录删除成功!');
                        var array = eval(data);
                        var newarray = array.leadHistoryId
                        var numarray = newarray.split(",");
                        $.each(numarray, function(i, v) {
                            var leng = $('.AddTable tbody').find('tr').length;
                            for (var y = 0; y < leng; y++) {
                                if ($('.AddTable tbody').find('tr').eq(y).attr('dataid') == v)
                                    $('.AddTable tbody').find('tr').eq(y).remove();
                            }
                        })
                        if ($('.AddTable tbody').find('tr').length == 0) {
                            $('.addClear,.againfp').hide();
                            $('#ClueDetail .btnsubmit').show();
                        }
                    } else {
                        Prompt.show(req.message);
                    }

                });
        });
        //线索在分配记录的删除
        $(document).on('click', '.addClear', function() {
            console.log($('.AddTable tbody tr').length > 0)
            if ($('.AddTable tbody tr').length < 0) {
                Prompt.show('没有数据可供操作！');
                return false;
            } else {
                var data = {
                    'leadId': $('#ClueDetail').attr('dataid')
                }
            }
            app.posttoken(app.url.api_base + "leads/refresh", data,
                function(req) {
                    if (req.code == 0) {
                        Prompt.show('分配记录删除成功!');
                        $('.addClear,.againfp').hide();
                        $('#ClueDetail .btnsubmit').show();
                    } else {
                        Prompt.show(req.message);
                    }

                });

        });

        //表格分页
        function pagefen(page, count) {

            $('#pageToolbar').Paging({
                pagesize: page,
                count: count,
                toolbar: true,
                callback: function(page, size, count) {
                    if (page == NaN) {
                        page = parseInt($('#pageToolbar .focus').html())
                    }
                    var data = _this.data;
                    data.pageIndex = page;
                    var type = app.getParameterByName('itype');
                    adddata(data, type);
                },
                callbacktwo: function(page, size, count) {
                    var pagenum = parseInt(size);
                    console.log(isNaN(pagenum))
                    if (isNaN(pagenum)) {
                        console.log($('.ui-select-pagesize option:selected').val())
                        pagenum = $('.ui-select-pagesize option:selected').val();
                    }
                    var data = _this.data;
                    console.log(data)
                    data.everyPage = pagenum;

                    // data.everyPage = pagenum;
                    var type = app.getParameterByName('itype');
                    adddata(data, type);
                }
            });
        };

        //ajax获取table数据
        //data 获取请求数据参数
        //type
        function adddata(data, type) {
            console.log(type)
            app.posttoken(app.url.api_base + "leads/list", data,
                function(req) {
                    if (req.code == 0) {
                        var data = req.data.list;
                        if (data.length > 0) {
                            var html = '';
                            $.each(data, function(i, v) {
                                html += '<tr id="' + v.id + '"><td> ';
                                if (v.leadPeriod == 'AUDITED') {
                                    html += '<input type="checkbox" id="' + v.id + '" disabled>';
                                } else {
                                    html += '<input type="checkbox" id="' + v.id + '" class="check">';
                                }
                                html += '</td><td>' + (i + 1);
                                html += '</td><td>' + v.name;
                                if (v.mobile != '') {
                                    html += '</td><td>' + v.mobile;
                                } else {
                                    html += '</td><td>' + v.telePhone;
                                }
                                if (v.gender == 'MALE') {
                                    html += '</td><td>男';
                                } else if (v.gender == 'FEMALE') {
                                    html += '</td><td>女';
                                } else {
                                    html += '</td><td>';
                                }
                                if (v.age > 0) {
                                    html += '</td><td>' + v.age;

                                } else {

                                    html += '</td><td>';
                                }
                                html += '</td><td>' + v.store;
                                html += '</td><td>' + v.city;
                                html += '</td><td>' + v.subjectType;
                                html += '</td><td>' + v.course;
                                html += '</td><td>' + (v.createTime).split(' ')[0];
                                html += '</td><td>' + (v.staffName).split(' ')[0];
                                html += '</td><td><img  src="../images/age.png"></td>';
                                if (app.getItem('role') == 'TMKManager' || app.getItem('role') == 'MarketManager') {
                                    if (type == 2 || type == 0) {
                                        html += '</td><td>' + v.leadStatus;
                                        html += '</td><td>' + (v.lastUpdateTime).split(' ')[0];
                                        $('.newstatus').show();
                                    } else {
                                        $('.newstatus').hide();
                                    }
                                } else {
                                    $('.newstatus').hide();
                                    $('.againfp,.addClear').hide();
                                }
                                // console.log(v.createTime)
                                if (type == 1) { // 管理者
                                    html += '<td><span class="Trial" >审批</span></td>';
                                } else if (type == 2) { //管理者

                                    html += '<td><span class="distribution">分配</span></td>';
                                } else if (type == 3) { //我的线索
                                    if (v.leadPeriod == 'UNSUMIT') {
                                        html += '<td class="istatus">未提交</td><td>';
                                        html += '<span class="Submit">提交</span><span class="del">作废</span><span  data-toggle="modal" data-target="#addClue" class="modify">修改</span>';
                                    } else if (v.leadPeriod == 'AUDITEDFAIL') {
                                        html += '<td class="istatus">未通过</td><td>';
                                        html += '<span class="Submit">提交</span><span class="del">作废</span><span  data-toggle="modal" data-target="#addClue" class="modify">修改</span>';
                                    }
                                    html += '</td>';

                                } else if (type == 0) {
                                    //判断角色 操作者显示 管理者隐藏
                                    //console.log(app.getItem('role'));
                                    //app.getItem('role') == 'TMKManager' || app.getItem('role') == 'MarketManager'
                                    if (app.getItem('role') == 'TMKStaff' || app.getItem('role') == 'MarketStaff') {
                                        if (v.leadPeriod == 'AUDITED') {
                                            html += '<td>已审核</td><td>';
                                        } else if (v.leadPeriod == 'AUDITEDFAIL') {
                                            html += '<td>未通过</td><td>';
                                            html += '<span style="visibility: hidden; display: inline-block;padding: 0px 15px;">撤回</span>';
                                            html += '<span class="del" data-toggle="modal" data-target="#SingleEel">作废</span>';
                                            html += '<span  data-toggle="modal" data-target="#addClue" class="modify">修改</span>';
                                        } else if (v.leadPeriod == 'UNAUDITED') {
                                            html += '<td>未审核</td><td>';
                                            html += '<span class="withdraw">撤回</span>';
                                        }
                                        html += '</td>';
                                    } else if (app.getItem('role') == 'TMKManager' || app.getItem('role') == 'MarketManager') {
                                        // html += '<td class="istatus">' + v.stutus + '</td>';
                                        // html += '<td>';
                                        // html += '<span class="withdraw">撤回</span>';
                                        // html += '<span class="del">删除</span>';
                                        // html += '<span  data-toggle="modal" data-target="#addClue" class="modify">修改</span>';
                                        // html += '</td>';


                                        //  if (v.leadPeriod == 'AUDITED') {
                                        //     //html += '<td class="istatus">已审核</td><td>';
                                        // } else if (v.leadPeriod == 'AUDITEDFAIL') {
                                        //     html += '<td class="istatus">未通过</td><td>';
                                        //     html += '<span style="visibility: hidden; display: inline-block;padding: 0px 15px;">撤回</span>';
                                        //     html += '<span class="del" data-toggle="modal" data-target="#SingleEel">删除</span>';
                                        //     html += '<span  data-toggle="modal" data-target="#addClue" class="modify">修改</span>';
                                        // } else if (v.leadPeriod == 'UNAUDITED') {
                                        //     html += '<td class="istatus">未审核</td><td>';
                                        //     html += '<span class="withdraw">撤回</span>';
                                        //     html += '<span  style="visibility: hidden; display: inline-block;padding: 0px 15px;">删除</span>';
                                        //     html += '<span  style="visibility: hidden; display: inline-block;padding: 0px 15px;">修改</span>';
                                        // }
                                        // html += '</td>';
                                    }
                                }
                                html += '</tr>';
                            })
                            $('.table tbody').html(html);
                            if (_this.data.pageIndex == 1 && _this.data.everyPage == 10) {
                                $('#pageToolbar').html('');
                                pagefen(_this.data.everyPage, req.data.count);
                            }
                            $('.table,#pageToolbar').fadeIn(300);;
                            $('.Inothing').hide();
                        } else {
                            // Prompt.show("抱歉！没有数据", '操作提示', function() {});
                            // return false;
                            $('.Inothing').show();
                        }
                    } else {
                        Prompt.show(req.message);
                    }
                    $('.icontent').fadeIn(100)
                });
        };

        //缓存table 单选值 string
        function sectionId() {
            var IdArray = '';
            $('.table .check').each(function() {
                if ($(this).is(':checked') == true) {
                    IdArray += $(this).attr('id') + ',';
                }
            });
            var stringid = IdArray.substring(0, IdArray.length - 1);
            return stringid
        };
        //缓存table 单选值 string
        function seesectionId() {
            var IdArray = '';
            $('.AddTable .check').each(function() {
                if ($(this).is(':checked') == true) {
                    IdArray += $(this).attr('id') + ',';
                }
            });
            var stringid = IdArray.substring(0, IdArray.length - 1);
            return stringid
        };

        //提交编辑或提交新建线索的验证
        function yanzheng() {
            var AddName = $('#AddName').val();
            var AddAge = $('#AddAge').val();
            var searchSEX = $("input[name='addSEX']:checked").val();
            var AddIphone = $('#AddIphone').val();

            var AddAreacode = $('#AddAreacode').val(); //地区号
            var Addtelyphone = $('#Addtelyphone').val(); //电话号
            var AddLandline = $('#AddLandline').val(); //座机号

            // var AddRelationship = $("#AddRelationship").find("option:selected").val();
            var AddSchool = $('#AddSchool').val();
            var AddCity = $('#AddCity option:selected').attr('value');
            var Addregion = $('#Addregion option:selected').attr('value');
            var shiye = $("input[name='shiye']:checked").val();
            var AddBranch = $('#AddBranch option:selected').attr('value');
            var AddSubject = $('#AddSubject option:selected').attr('value');
            var AddClass = $('#AddClass option:selected').attr('value');
            var AddCourse = $('#AddCourse option:selected').attr('value');
            var AddSource = $('#AddSource option:selected').attr('value');
            var AddSourcetwo = $('#AddSourcetwo option:selected').attr('value');
            var AddStuName = $('#AddStuName').val();
            var AddEmail = $('#AddEmail').val();
            var AddAddress = $('#AddAddress').val();
            var AddRemarks = $('#AddRemarks').val();
            var Interest = '';
            var filter = /^1\d{10}$/; //手机号
            var reg = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/; //邮箱
            if (AddName == '') {
                Prompt.show('姓名不能为空!', '操作提示', function() {});
                return false;
            }
            if (AddAge == '') {
                // Prompt.show('年龄不能为空!', '操作提示', function() {});
                // return false;
            } else {
                if (AddAge > 110) {
                    Prompt.show('年龄不能大于110岁!', '操作提示', function() {});
                    return false;
                } else if (AddAge < 1) {
                    Prompt.show('年龄不小于1岁!', '操作提示', function() {});
                    return false;
                }

            }
            //console.log(searchSEX)
            // if(searchSEX==undefined){
            //      Prompt.show('性别不能为空!', '操作提示', function() {});
            //     return false;
            // }
            if (AddIphone != '') {
                if (filter.test(AddIphone) == false) {
                    Prompt.show("手机号格式错误", '操作提示', function() {});
                    return false;
                }
            } else {
                if (Addtelyphone == '') {
                    Prompt.show("请输入有效的联系方式", '操作提示', function() {});
                    return false;
                } else {
                    if (Addtelyphone.length < 5) {
                        Prompt.show("请输入有效的电话号", '操作提示', function() {});
                        return false;
                    }
                    if (AddAreacode == '') {
                        Prompt.show("请输入区号(如上海：021)", '操作提示', function() {});
                        return false;
                    } else {
                        if (AddAreacode.length < 3) {
                            Prompt.show("请输入有效的区号", '操作提示', function() {});
                            return false;
                        }
                    }
                }




            }

            if (AddCity == '') {
                Prompt.show('城市不能为空!', '操作提示', function() {});
                return false;
            }
            if (Addregion == '') {
                Prompt.show('地区不能为空!', '操作提示', function() {});
                return false;
            }
            if (shiye == undefined) {
                Prompt.show('学科不能为空!', '操作提示', function() {});
                return false;
            }
            if (AddBranch == '') {
                Prompt.show('分馆不能为空!', '操作提示', function() {});
                return false;
            }
            if (shiye == 'LITERATURE') {
                if (AddClass == '') {
                    Prompt.show('年级不能为空!', '操作提示', function() {});
                    return false;
                }
            } else if (shiye == 'ART') {
                if (AddSubject == '') {
                    Prompt.show('科目不能为空!', '操作提示', function() {});
                    return false;
                }
            }
            if (AddSource == '') {
                Prompt.show('一级线索来源不能为空!', '操作提示', function() {});
                return false;
            }
            if (AddSourcetwo == '') {
                Prompt.show('二级线索来源不能为空!', '操作提示', function() {});
                return false;
            }
            if (AddSourcetwo == undefined) {
                Prompt.show('二级线索来源不能为空!', '操作提示', function() {});
                return false;
            }
            if (AddEmail != '') {
                if (reg.test(AddEmail) == false) {
                    Prompt.show("邮箱格式错误", '操作提示', function() {});
                    return false;
                }
            }
            $('.addcourse .active').each(function() {
                Interest += $(this).attr('id') + ','
            });
            if (AddLandline != '') {
                var telePhone = AddAreacode + '-' + Addtelyphone + '-' + AddLandline;
            } else {
                var telePhone = AddAreacode + '-' + Addtelyphone;
            }
            if (telePhone == '-') {
                telePhone = "";
            }
            console.log(telePhone)
            var newstr = Interest.substring(0, Interest.length - 1);
            var data = {
                'name': AddName,
                'age': AddAge,
                'mobile': AddIphone,
                'telePhone': telePhone,
                'sourceId': AddSource,
                'childSourceId': AddSourcetwo,
                'courseId': AddCourse,
                'gradeId': AddClass,
                'storeId': AddBranch,
                'cityCode': AddCity,
                'districtCode': Addregion,
                'subjectId': AddSubject,
                'subjectType': shiye,
                'address': AddAddress,
                'email': AddEmail,
                'schoolName': AddSchool,
                'interestPointIds': newstr,
                'gender': searchSEX,
                'studentName': AddStuName,
                'note': AddRemarks,
            };
            return data;
        }

        //添加订单跟踪数据
        function addgenjin(date) {
            var html = '';
            if (date.length > 0) {
                $.each(date, function(i, v) {
                    html += '<tr dataid="' + v.leadHistoryId + '" ><td class="itypeshow" ><input type="checkbox" id="' + v.leadHistoryId + '" class="check"></td>';
                    html += '<td>' + (new Date(v.createTime)).Format('yyyy-MM-dd hh:mm');
                    html += '</td><td>' + v.status;;
                    html += '</td><td>' + v.companyName + '-' + v.storeName;
                    html += '</td><td>' + v.ccName;
                    html += '</td><td>' + v.note + '</td><td class="itypeshow">';
                    html += '<span class="adddel" id="' + v.leadHistoryId + '">删除</span>';
                    html += '</td></tr>';
                })

                $('.AddTable tbody').html(html);
                $('.againfp,.AddTable').show();
            }
        }

        //获取课科
        function loadcourseorclass() {
            var radio = $('input:radio[name="shiye"]:checked').val();
            console.log(radio)
            if (radio == 'LITERATURE') {
                app.posttoken(app.url.api_base + "selections/grades", {},
                    function(req) {
                        if (req.code == 0) {
                            var data = req.data.grades;
                            if (data.length > 0) {
                                // var html = '<option value="">请选择</option>';
                                var html = '';
                                $.each(data, function(i, v) {
                                    if (i == 0) {
                                        html += '<option value="' + v.id + '" selected = "selected">' + v.text + '</option>'
                                    } else {
                                        html += '<option value="' + v.id + '">' + v.text + '</option>'
                                    }
                                });
                                $('#AddClass').html(html);
                                loadCourse();

                                $('.Iaddsubiet').hide();
                                $('.Iaddclass').show();
                            }
                        } else {
                            Prompt.show(req.message);
                        }
                    });
            } else if (radio == 'ART') {
                app.posttoken(app.url.api_base + "selections/subjects", {},
                    function(req) {
                        if (req.code == 0) {
                            var data = req.data.subjects;
                            if (data.length > 0) {
                                // var html = '<option value="">请选择</option>';
                                var html = '';
                                $.each(data, function(i, v) {
                                    if (i == 0) {
                                        html += '<option value="' + v.id + '" selected = "selected">' + v.text + '</option>'
                                    } else {
                                        html += '<option value="' + v.id + '">' + v.text + '</option>'
                                    }
                                });
                                $('#AddSubject').html(html);
                                 $('.Iaddsubiet').show();
                                $('.Iaddclass').hide();
                                loadCourse();

                            }
                        } else {
                            Prompt.show(req.message);
                        }
                    });
            }
            //获取数据
                    }

        //课程选择
        function loadCourse(){
            $('#AddCourse option').remove()
            // #AddClass,#AddSubject
            // console.log($('#AddClass').val())
            // console.log($('#AddSubject').val())
            if($('#AddClass').val()!='' || $('#AddClass').val()!=null){
             var sval = $('#AddClass').val();
            }else if($('#AddSubject').val()!='' || $('#AddSubject').val()!=null){
                var sval = $('#AddSubject').val();
            }else{
                // Prompt.show('请先选择课程', '操作提示', function() {});
                return false;
            }
            var radio = $('input:radio[name="shiye"]:checked').val();
            var data = {};
            if (radio == 'LITERATURE') {
                data.gradeId = sval;
                data.subjectType = 'LITERATURE';
               
            } else if (radio == 'ART') {
                data.subjectType = 'ART';
                data.subjectId = sval;
                
            }

            app.posttoken(app.url.api_base + "selections/courses", data,
                function(req) {
                    if (req.code == 0) {
                        var data = req.data.courses;
                        if (data.length > 0) {
                            var html = '';
                            // var html = '<option value="">请选择</option>';
                            $.each(data, function(i, v) {
                                if (i == 0) {
                                    html += '<option value="' + v.id + '" selected = "selected">' + v.text + '</option>'
                                } else {
                                    html += '<option value="' + v.id + '" >' + v.text + '</option>'
                                }
                            });

                            $('#AddCourse').html(html);
                        }
                    } else {
                        Prompt.show(req.message);
                    }
                });
        }

        //获取number
        function getNumber(){
              app.posttoken(app.url.api_base + "leads/count-potential",{},function(req){
                if(req.code==0){
                    $('.shownum i').html(req.data.count);
                }
              },true)
        }

        //添加合同初始化
        function AddInitData() {
            $('#addClue').modal('show');
            $('#addClue').removeAttr('dataid');
            $('#addClue').find('input:text').val('');
            $('#addClue h4').html('添加线索<span class="shownum">待处理名单<i> 0 </i>条</span>');
            // $("#AddRelationship").get(0).selectedIndex = 0;
            //弹框显示 清空数据
            $('#AddCity option').remove();
            $('#Addregion option').remove();
            $('#AddBranch option').remove();
            $('#AddSubject option').remove();
            $('#AddClass option').remove();
            $('#AddCourse option').remove();
            $('#AddSource option').remove();
            $('#AddSourcetwo option').remove();
            $('input:radio[name="shiye"]').attr('checked', false);
            $('input:radio[name="addSEX"]').attr('checked', false);
            $('.addcourse span').removeClass('active');
            $('#AddAddress,#AddRemarks,#AddLandline,#AddAreacode,#Addtelyphone').val('');
            $('.addsubmint').show();
            $('.addcencal').hide();
            $('#addClue .addClue').html('保存并新建');
            $('#addClue .addClue').hide();
            $('#addClue .addsubmintNew').show();
            $("#AddIphone").attr("readOnly", false);
            $("input[name='addSEX'][value='MALE']").prop("checked", true);
            $("input[name='shiye'][value='LITERATURE']").prop("checked", true);
            getNumber();
            //获取城市
            app.posttoken(app.url.api_base + "selections/citys", {},
                function(req) {
                    if (req.code == 0) {
                        var data = req.data.citys;
                        if (data.length > 0) {
                            var html = '<option value="">请选择</option>';
                            $.each(data, function(i, v) {
                                html += '<option value="' + v.id + '">' + v.text + '</option>'
                            });
                            $('#AddCity').html(html);
                        }
                    } else {
                        Prompt.show(req.message);
                    }
                });

            //获取兴趣点 selections/interest-points
            app.posttoken(app.url.api_base + "selections/interest-points", {},
                function(req) {
                    if (req.code == 0) {
                        var data = req.data.interestPoints;
                        if (data.length > 0) {
                            var html = '';
                            $.each(data, function(i, v) {
                                html += '<li><span id="' + v.id + '">' + v.text + '</span></li>'
                            });
                            $('.addcourse').html(html);
                        }
                    } else {
                        Prompt.show(req.message);
                    }
                });

             loadcourseorclass();

            //获取线索
            app.posttoken(app.url.api_base + "leads/prepare-create", {}, function(req) {
                if (req.code == 0) {
                    var data = req.data;
                    $('#addClue').attr('potent', data.potentialId)
                    $('#AddName').val(data.name);
                    $('#AddStuName').val(data.studentName);
                    $('#AddIphone').val(data.mobile);
                    $("#AddIphone").attr("readOnly", true);
                    var AddSource = '<option value="' + data.sourceId + '" selected = "selected" >' + data.sourceName + '</option>';
                    $('#AddSource').html(AddSource);
                    var AddSourcetwo = '<option value="' + data.childSourceId + '" selected = "selected" >' + data.childSourceName + '</option>'
                    $('#AddSourcetwo').html(AddSourcetwo);
                    $('.addBtninvalid,.addBtnAgain').show();
                } else {
                    $('.addBtninvalid,.addBtnAgain').hide();
                    //线索来源
                    app.posttoken(app.url.api_base + "selections/first-sources", {},
                        function(req) {
                            if (req.code == 0) {
                                var data = req.data.sources;
                                // console.log(data.length)
                                if (data.length > 0) {
                                    var html = '<option value="">请选择</option>';
                                    $.each(data, function(i, v) {
                                        html += '<option value="' + v.id + '">' + v.text + '</option>'
                                    });
                                    $('#AddSource').html(html);
                                }
                            } else {
                                Prompt.show(req.message);
                            }
                        });

                }
            }, true);
        }

    }
    var index = new indexpage();
});