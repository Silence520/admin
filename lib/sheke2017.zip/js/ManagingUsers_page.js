$(function(){
		//判断是否登陆
		if(app.getItem('user') !=''){
			function loadData(){
				this.data={
					
				}
				this.init();
			}
		}else{
			app.go('login.html')
		}


		loadData.prototype.init=function(){
			var _this=this;


			

		}

		new loadData();
})