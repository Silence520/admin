$(function(){
		 //表格数据请求
        $('.username').html(app.getItem('userName'));
        //初始化获取部门人员列表
        setJoinlist();
        setSourcelist();
        //退出登陆 ok
        $(document).on('click', '.SignOut', function() {
            var data = {
                accessToken: app.getItem('userToken')
            }
            app.posttoken(app.url.api_base + "logout", data,
                function(req) {
                    if (req.code == 0) {
                        app.removeItem('role');
                        app.removeItem('userName');
                        app.removeItem('userId');
                        app.removeItem('userToken');
                        app.go('login.html');
                    } else {
                        Prompt.show(req.message);
                    }
                });
        });

        //修改密码
        $(document).on('click', '#ChangePass .btn-primary', function() {
            var old = $('#oldpass').val();
            var newpass = $('#newpass').val();
            var again = $('#querenpass').val();
            if (old == '') {
                Prompt.show('旧密码不能为空!', '操作提示', function() {});
                return false;
            }
            if (newpass == '') {
                Prompt.show('新密码不能为空!', '操作提示', function() {});
                return false;
            }
            if (again == '') {
                Prompt.show('确认密码不能为空!', '操作提示', function() {});
                return false;
            }
            if (newpass != again) {
                Prompt.show('两次密码不一致!', '操作提示', function() {});
                return false;
            }

            var data = {
                'oldPassword': $.md5(old),
                'newPassword': $.md5(newpass),
            };
            app.posttoken(app.url.api_base + "leads/change-password", data,
                function(req) {
                    if (req.code == 0) {
                        $('#ChangePass').modal('hide');
                        Prompt.show(req.message);

                    } else {
                        Prompt.show(req.message);
                    }
                });
        })

        //提交部门内置人员修改
        $(document).on('click','.allbtnperson',function(){
        	var idarray='', 
        		result ='';
        	$('.setJoinTable tbody tr').each(function(i,v){
        		 result +=$(this).find("input[type='radio']:checked").val()+',';
        	     idarray +=$(this).find("input[type='radio']:checked").prop('name').replace('per','')+',';
        	})
        	if(idarray==''){
        		Prompt.show("修改成功！");
        		return false;
        	}

           var data={
           	'staffRoleId':idarray.substring(0, idarray.length - 1),
           	'needAudit':result.substring(0, result.length - 1)
           }
            app.posttoken(app.url.api_base + "audit/staff-audit", data,
               function(req) {
                   if (req.code == 0) {
                       Prompt.show("修改成功！");
                   } else {
                       Prompt.show(req.message);
                   }
            });
        })

        //提交线索来源修改
        $(document).on('click','.allbtnproduct',function(){
        	console.log('111')
        		var idarray='', 
        			result ='';
        		$('.setSourceTable tbody tr li').each(function(i,v){
        			 result +=$(this).find("input[type='radio']:checked").val()+',';
        		     idarray +=$(this).find("input[type='radio']:checked").prop('name').replace('per','')+',';
        		})
        		if(idarray==''){
        			Prompt.show("修改成功！");
        			return false;
        		}
        	   var data={
        	   	'sourceId':idarray.substring(0, idarray.length - 1),
        	   	'needAudit':result.substring(0, result.length - 1)
        	   }
        	   app.posttoken(app.url.api_base + "audit/source-audit", data,
        	       function(req) {
        	           if (req.code == 0) {
        	               Prompt.show("修改成功！");
        	           } else {
        	               Prompt.show(req.message);
        	           }
        	   });
        })
        //获取部门内置人员列表
		function setJoinlist(){
			app.posttoken(app.url.api_base + "audit/staffs", {} , function(req){
				var data=req.data.staffRoleListResponse;
				var html='';
				$.each(data,function(i,v){
					html+='<tr><td><span class="marginone">'+v.name+'</span><label class="marginleft20">';
					if(v.needAudit==true){
					html+='<input type="radio" name="per'+v.staffRoleId+'"  value="true" checked> ';
					}else{
					html+='<input type="radio" name="per'+v.staffRoleId+'" value="true" > ';
					}
					html+='开启审批</label><label>';
					if(v.needAudit==true){
					html+='<input type="radio" name="per'+v.staffRoleId+'" value="false" > ';
					}else{
					html+='<input type="radio" name="per'+v.staffRoleId+'" value="false" checked  > ';
						
					}
					html+='关闭审批</label></td></tr>';
				})
				$('.setJoinTable tbody').html(html)
			}, true)
		}
		//获取线索来源列表
		function setSourcelist(){
			app.posttoken(app.url.api_base + "audit/sources", {} , function(req){
				var data=req.data.sourceListResponse;
				var html='';
				$.each(data,function(i,v){
					html+='<tr><td><span class="marginone">'+v.name+'</span> ';
					html+='<label  class="marginleft20">';
					html+='<input type="radio" name="'+v.sourceId+'" value="1"> ';
					html+='统一开启审批</label><label>';
					html+='<input type="radio" name="'+v.sourceId+'" value="0"> ';
					html+='统一关闭审批</label><label>';
					html+='<input type="radio" name="'+v.sourceId+'" value="2"> ';
					html+='自定义审批</label>';
					html+='<ul class="childlist">';
					$.each(v.secondSources,function(ii,vv){
						html+='<li><span class="marginone">'+vv.name+'</span><label  class="marginleft20">';
						if(vv.needAudit==true){
						html+='<input type="radio" name="'+vv.sourceId+'"  value="true" checked> ';
						}else{
						html+='<input type="radio" name="'+vv.sourceId+'"  value="true"> ';
						}
						html+='统一开启审批</label><label>';
						if(vv.needAudit==true){
						html+='<input type="radio" name="'+vv.sourceId+'"  value="false" > ';
						}else{
						html+='<input type="radio" name="'+vv.sourceId+'"  value="false" checked> ';
						}
						html+='统一关闭审批</label></li>';
					})
					html+='</ul></td></tr>';
				})
				$('.setSourceTable tbody').html(html)
			}, true)
		}
})

