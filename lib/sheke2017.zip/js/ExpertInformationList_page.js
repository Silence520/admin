$(function() {
	//判断是否登陆
	if(app.getItem('user') !=''){
		function loadData(){
			if(window.location.hash){
				var num=window.location.hash;
			    num=(num.split('=')[1]);
			}else{
				var num=1;
			}
			this.data={
				pageNo: num,
                everyPage: 10,
				name:app.getItem('userName'),
				userToken:app.getItem('userToken'),
				userId:app.getItem('userId'),
				companyId:app.getItem('companyId'),
				code:'',
				name:'',
				age:'',
				relationMobile:'',
				skillJob:'',
				subject:'',
			}
			this.init();
		}
	}else{
		app.go('login.html')
	}


	//原型读写数据
	loadData.prototype.init=function(){
		var _this=this;
		loadList(_this.data)
		var count=0;
		var indexpage=true;


	//搜索条件 SeaJob 专技职务
	var data={
	    type:1
	}
	app.post(app.url.api_base+"dictQuery/queryData.do",data,
	     function(req) { 
	          if(req.code==0){
	            var html='<option value="">请选择专技职务</option>';
	            var data=req.items;
	             $.each(data,function(i,v){
	                html+='<option value="'+v.id+'">'+v.value+'</option>';
	             })
	             $('#SeaJob').html(html);
	           }else{
	             Prompt.show(req.message)
	           }
	     },false);


	//搜索条件 学科/专业
	searchObject();
	function searchObject(){
		var data={
		    parentCode:0,
		    type:1
		}
		app.post(app.url.api_base+"dataQuery/queryData.do",data,
		     function(req) { 
		          if(req.code==0){
		            var html='<option value="">请选择学科/专业</option>';
		            var data=req.items;
		             $.each(data,function(i,v){
		                html+='<option value="'+v.id+'">'+v.value+'</option>';
		             })
		             $('#SeaObject').html(html);
		           }else{
		             Prompt.show(req.message)
		           }
		     },false);
	}

	//线索搜索提交
	$(document).on('click', '.btnsearch', function() {
	    var SeaNo = $('#SeaNo').val().trim();
	    var SeaName = $('#SeaName').val().trim();
	    var SeaPhone = $('#SeaPhone').val().trim();
	    var SeaJob=$('#SeaJob option:selected').val()
	    var SeaJobt=$('#SeaJob option:selected').html()
	    var SeaAge = $('#SeaAge').val().trim();
	    var SeaObject=$('#SeaObject option:selected ').val()
	    var SeaObjectt=$('#SeaObject option:selected ').html()
	    var html = '<span>热搜词：</span>';
	    if (SeaNo != '') {
	        html += '<span>' + SeaNo + '</span>';
	    }
	    if (SeaName != '') {
	        html += '<span>' + SeaName + '</span>';
	    }
	    if (SeaPhone != '') {
	        html += '<span>' + SeaPhone + '</span>';
	    }
	    if (SeaJob != '') {
	        html += '<span>' + SeaJobt + '</span>';
	    }
	    if (SeaAge != '') {
	        html += '<span>' + SeaAge + '</span>';
	    }
	    if (SeaObject != '') {
	        html += '<span>' + SeaObjectt + '</span>';
	    }
	    _this.data.code = SeaNo;
	    _this.data.name = SeaName;
	    _this.data.age = SeaAge;
	    _this.data.relationMobile = SeaPhone;
	    _this.data.skillJob = SeaJob;
	    _this.data.subject = SeaObject;
	    _this.data.pageNo = 1;
	    _this.data.everyPage = 10;
	  
	   
	    $('.searchCriteria').html(html)
	    if ($('.searchCriteria').find('span').length > 1) {
	        $('#pageToolbar,.table').hide();
	        loadList(_this.data);
	    } else {
	        Prompt.show("搜索条件为空！", '操作提示', function() {});
	        return false;
	    }

	});

	//重置搜索条件
    $(document).on('click', '.iRefresh', function() {
            _this.data.code = '';
       	    _this.data.name = '';
       	    _this.data.age = '';
       	    _this.data.relationMobile = '';
       	    _this.data.skillJob = '';
       	    _this.data.subject = '';
       	    _this.data.pageNo = 1;
       	    _this.data.everyPage = 10;
       	    // 清空hash
       	    window.location.hash='';
        	loadList(_this.data);
        	$('.searchCriteria').html('<span>热搜词：</span>')
    });

    //删除一个列表
    $(document).on('click','.table .del' ,function(){
    	var deleteData={
                id:$(this).attr('dataid'),
                userToken:app.getItem('userToken'),
                userId:app.getItem('userId'),
                companyId:app.getItem('companyId')
            }
            app.post( app.url.api_base+"role/deleteRole.do",deleteData,
                     function(req) { 
                          Prompt.show(req.message);
                           if(req.code==0){
                               loadList(_this.data);
                           }
                 },true);
    });

	//表格分页
	 function pagefen(page, count) {

          $('#pageToolbar').Paging({
              pagesize: 10,
              count: count,
              toolbar: false,
              callback: function(page, size, count) {
                  if (page == NaN) {
                      page = parseInt($('#pageToolbar .focus').html())
                  }
                  var data = _this.data;
                  data.pageNo = page;
                  loadList(data);
              },
              // callbacktwo: function(page, size, count) {
              //     var pagenum = parseInt(size);
              //     console.log(isNaN(pagenum))
              //     if (isNaN(pagenum)) {
              //         pagenum = $('.ui-select-pagesize option:selected').val();
              //     }
              //     var data = _this.data;
              //     data.everyPage = pagenum;
              //     loadList(data);
              // }
          });
     };

     //加载数据
     function loadList(dataarray){ 
        app.post( app.url.api_base+"expert/getExpertList.do",dataarray,
                 function(req) { 
                      if(req.code==0){
                         //清空个数据
                         $('.table tbody').html('')
                        var data=req.items;
                        if(data.length>0){
                            var html='';
                            $.each(data,function(i,v){
	                            html+='<tr>';
			                	html+='<td>'+v.code;
			                	html+='</td>';
			                	html+='<td>'+v.name;
			                	html+='</td>';
			                	html+='<td>'+v.relationMobile;
			                	html+='</td>';
			                	html+='<td>'+v.professionalLevelStr;
			                	html+='</td>';
			                	html+='<td>'+v.subjectStr;
			                	html+='</td>';
			                	html+='<td>'+v.researchStr;
			                	html+='</td>';
			                	html+='<td>'+v.factory;
			                	html+='</td>';
			                	html+='<td>'+v.status;
			                	html+='</td>';
			                	html+='<td>';
                                html+='<a href="ExpertInformationDetail.html?NO='+v.id+'">查看</a>';
                                html+='<a href="ExpertInformationDetail.html?NO='+v.id+'">修改</a>';
                                html+='<span class="del" dataid="'+v.id+'">刪除</span>';                   
			                	html+='</td>';
			                	html+='</tr>';

                            });
                             $('.table tbody').html(html)
                             count=req.totalcount;
                             if (indexpage ==true ) {
                                 $('#pageToolbar').html('');
                                 pagefen(_this.data.everyPage,count);
                                 indexpage=false
                             }
                               $('.table,#pageToolbar').show();
                               $('.Inothing').hide();
                        }else{
                             indexpage=true;
                             $('.table,#pageToolbar').hide();
                             $('.Inothing').show();
                             $('.tab-content').html('<p class="NoData">暂无数据！</p>');
							 //清除分页
                        	 $('#pageToolbar .ui-paging-container').remove();
                        }
                       }else{
                         Prompt.show(req.message)
                       }
             },true);
        }
	}


















 new loadData();	
})

