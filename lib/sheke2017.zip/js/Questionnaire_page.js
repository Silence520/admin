
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>智库专家信息交互平台--管理登录</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" type="icon" href="../images/hutong.png">
    <link href="../lib/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/common.css" rel="stylesheet">
    <link href="../css/Questionnaire_page.css" rel="stylesheet">
    <!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <!-- The fav icon -->
</head>

<body class="loginbody">
    <div class="container-full">
       
    </div>
    <script src="https://cdn.bootcss.com/jquery/1.12.4/jquery.min.js"></script>
    <script src="../lib/jquery/jquery-ui.min.js"></script>
    <script src="../lib/js/bootstrap.min.js"></script>
    <script src="../lib/app.js"></script>
    <script src="../js/Questionnaire_page.js"></script>
</body>

</html>
