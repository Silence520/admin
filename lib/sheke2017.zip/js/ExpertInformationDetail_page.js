$(function() {
    //判断是否登陆
    if (app.getItem('userName')) {
        function loadData() {
            this.init();
        }
    } else {
        app.go('login.html')
    }

    loadData.prototype.init = function() {
        var _this = this;
        var indexno='';
        // 学科/专业
        var data={
            type:1
        }
        app.post(app.url.api_base+"dictQuery/queryData.do",data,
             function(req) { 
                  if(req.code==0){
                    var html='<option value="">请选择学科/专业</option>';
                    var data=req.items;
                     $.each(data,function(i,v){
                        html+='<option value="'+v.code+'">'+v.value+'</option>';
                     })
                     $('#AddSubject').html(html);
                   }else{
                     Prompt.show(req.message)
                   }
             },false);

        //研究领域
        $(document).on('change','#AddSubject',function(){
              $('#researchField option').remove()
            var data={
                type:2,
                parentCode:$(this).val()

            }
            app.post(app.url.api_base+"dictQuery/queryData.do",data,
                 function(req) { 
                      if(req.code==0){
                        var html='<option value="">请选择研究领域</option>';
                        var data=req.items;
                         $.each(data,function(i,v){
                            html+='<option value="'+v.code+'">'+v.value+'</option>';
                         })
                         $('#researchField').html(html);
                       }else{
                         Prompt.show(req.message)
                       }
                 },false);
        })
            //工作地点 城市
             var data={
                layer:1
              }
            app.post(app.url.api_base+"common/getbyLayer.do",data,
                 function(req) { 
                      if(req.code==0){
                        var html='<option value="">请选择城市</option>';
                        var data=req.items;
                         $.each(data,function(i,v){
                            html+='<option value="'+v.id+'">'+v.name+'</option>';
                         })
                         $('#AddCity').html(html);
                       }else{
                         Prompt.show(req.message)
                       }
            },false);
        
            // Addregion 二级城市
            $(document).on('change','#AddCity',function(){
                $('#Addregion option').remove();
                var AddCity=$(this).val();
                 var data={
                    parentId:AddCity
                  }
                app.post(app.url.api_base+"common/getbyParentId.do",data,
                     function(req) { 
                          if(req.code==0){
                            var html='<option value="">请选择城市</option>';
                            var data=req.items;
                             $.each(data,function(i,v){
                                html+='<option value="'+v.id+'">'+v.name+'</option>';
                             })
                             $('#Addregion').html(html);
                           }else{
                             Prompt.show(req.message)
                           }
                },false);
                
            })

            //
            var dataone={
                type:1,
                id:0
            }
            app.post(app.url.api_base+"dataQuery/queryData.do",dataone,
                 function(req) { 
                      if(req.code==0){
                        var html='<option value="">请选择一级专技职务</option>';
                        var data=req.items;
                         $.each(data,function(i,v){
                            html+='<option value="'+v.id+'">'+v.value+'</option>';
                         })
                         $('#TechnicalDuty1').html(html);
                       }else{
                         Prompt.show(req.message)
                       }
            },false);
            //三级
            var dataone={
                type:3,
                id:0
            }
            app.post(app.url.api_base+"dataQuery/queryData.do",dataone,
                 function(req) { 
                      if(req.code==0){
                        var html='<option value="">请选择三级级专技职务</option>';
                        var data=req.items;
                         $.each(data,function(i,v){
                            html+='<option value="'+v.id+'">'+v.value+'</option>';
                         })
                         $('#TechnicalDuty3').html(html);
                       }else{
                         Prompt.show(req.message)
                       }
            },false);
            //二级
            $(document).on('change','#TechnicalDuty1',function(){
                $('#TechnicalDuty2 option').remove();
                var TechnicalDuty1=$(this).val();
                console.log(TechnicalDuty1)
                var data={
                    id:TechnicalDuty1,
                    type:1,
                  }
                app.post(app.url.api_base+"dataQuery/queryData.do",data,
                    function(req) { 
                         if(req.code==0){
                           var html='<option value="">请选择二级级专技职务</option>';
                           var data=req.items;
                            $.each(data,function(i,v){
                               html+='<option value="'+v.id+'">'+v.value+'</option>';
                            })
                            $('#TechnicalDuty2').html(html);
                          }else{
                            Prompt.show(req.message)
                          }
               },false);
            })

            //
            var data={
                type:2,
            }
            app.post(app.url.api_base+"dataQuery/queryData.do",dataone,
                 function(req) { 
                      if(req.code==0){
                        var html='<option value="">请选择三级级专技职务</option>';
                        var data=req.items;
                         $.each(data,function(i,v){
                            html+='<option value="'+v.id+'">'+v.value+'</option>';
                         })
                         $('#TechnicalDuty3').html(html);
                         if (app.getParameterByName('NO')){
                            loadEditor();
                          }
                       }else{
                         Prompt.show(req.message)
                       }
            },false);

       
         function loadEditor(){ //编辑
            var datano={
                userToken:app.getItem('userToken'),
                userId:app.getItem('userId'),
                id:app.getParameterByName('NO'),
              }
            app.post(app.url.api_base+"expert/searchExpertDetail.do",datano,
                 function(req) { 
                      if(req.code==0){
                        var data=req.detailinfo;
                        $('#Name').val(data.name);
                        $('#IDNumber').val(data.idNo);
                        if(data.sex=='男'){
                            $("input[name='addSEX'][value='女']").removeAttr("checked");
                            $("input[name='addSEX'][value='男']").prop("checked", true);
                        }else if(data.sex=='女'){
                            $("input[name='addSEX'][value='男']").removeAttr("checked");
                            $("input[name='addSEX'][value='女']").prop("checked", true);
                        }
                        $('#PostalAddress').val(data.address);
                        $('#PersonEmail').val(data.email);
                        $('#AddSubject option:selected').val(data.subjectStr);
                        $('#ResearchDirection1').val(data.research1);
                        $('#GraduationSchool').val(data.school);
                        $('#ForeignLanguage').val(data.language);
                        $('#ImportantAward').val(data.awards);
                        $('#TalentTitle').val(data.talentPlan);
                        $('#Mainstream').val(data.mediaInterview);
                        $('#ContactMobile').val(data.relationMobile);
                        $('#DateBirth').val(data.birthday);
                        $('#WorkUnit').val(data.factory);
                        $('#PostalCode').val(data.postCode);
                        $('#Telephone').val(data.phone);
                        $('#AdministrativeDuty').val(data.adminJob);
                        $('#ResearchDirection2').val(data.research2);
                        $('#WechatNumber').val(data.weixin);
                        $('#RepresentativeWork').val(data.magnumOpus);
                        $('#JobStatus').val(data.association);
                        $('#ImportantIssues').val(data.topic);
                        $('#Cardholder').val(data.bankName);
                        $('#OpeningBranch').val(data.bank);
                        $('#CardNumber').val(data.bankCard);
                        $("#DocumentType").find("option[value='"+data.idType+"']").attr("selected",true);
                        $("#TechnicalDuty2").find("option[value='"+data.professionalLevel+"']").attr("selected",true);
                        $("#TechnicalDuty3").find("option[value='"+data.jobLevel+"']").attr("selected",true);
                        $("#AddSubject").find("option[value='"+data.subject+"']").attr("selected",true);
                        $("#AcademicDegree").find("option[value='"+data.degree+"']").attr("selected",true);
                        $("#AddCity").find("option[value='"+data.workPlace1+"']").attr("selected",true);
                        $("#TechnicalDuty1").find("option[value='"+data.skillJob+"']").attr("selected",true);
                        $("#researchField").find("option[value='"+data.degree+"']").attr("selected",true);
                        $("#Education").find("option[value='"+data.education+"']").attr("selected",true);
                        addregion(data.workPlace1,data.workPlace2);
                        addjob(data.skillJob,data.professionalLevel);
                        research(data.subject,data.research);x
                       }else{
                         Prompt.show(req.message)
                       }
            },false);


        } 

    //获取二级专技职务
    function addjob(TechnicalDuty1,attrstr){
         var data={
             id:TechnicalDuty1,
             type:1,
           }
         app.post(app.url.api_base+"dataQuery/queryData.do",data,
             function(req) { 
                  if(req.code==0){
                    var html='<option value="">请选择二级级专技职务</option>';
                    var data=req.items;
                     $.each(data,function(i,v){
                        if(v.id==attrstr){
                         html+='<option value="'+v.id+'" selected = "selected">'+v.value+'</option>';
                        }else{
                         html+='<option value="'+v.id+'">'+v.value+'</option>';  
                        }
                     })
                     $('#TechnicalDuty2').html(html);
                   }else{
                     Prompt.show(req.message)
                   }
        },false);
    }
    //获取编辑的二级城市
    function addregion(AddCity,attrid){
         var data={
            parentId:AddCity
          }
        app.post(app.url.api_base+"common/getbyParentId.do",data,
             function(req) { 
                  if(req.code==0){
                    var html='<option value="">请选择城市</option>';
                    var data=req.items;
                     $.each(data,function(i,v){
                        if(v.id==attrid){
                            html+='<option value="'+v.id+'" selected = "selected">'+v.name+'</option>';

                        }else{
                            html+='<option value="'+v.id+'">'+v.name+'</option>'; 
                        }
                     })
                     $('#Addregion').html(html);
                   }else{
                     Prompt.show(req.message)
                   }
        },false);
    }
    //获取编辑的二级领域
    function research(dataid,attrid){
        var data={
            type:2,
            parentCode:dataid,

        }
        app.post(app.url.api_base+"dictQuery/queryData.do",data,
             function(req) { 
                  if(req.code==0){
                    var html='<option value="">请选择研究领域</option>';
                    var data=req.items;
                     $.each(data,function(i,v){
                        if(v.code==attrid){
                        html+='<option value="'+v.code+'"  selected = "selected">'+v.value+'</option>';
                        }else{
                        html+='<option value="'+v.code+'">'+v.value+'</option>';
                        }
                     })
                     $('#researchField').html(html);
                   }else{
                     Prompt.show(req.message)
                   }
             },false); 
    }


    //验证
    function Validate() {
        var Name = $('#Name').val().trim();
        var IDNumber = $('#IDNumber').val().trim();
        var sex = $('input[name="addSEX"]:checked').val();
        var AddCity = $('#AddCity option:selected').val();
        var AddCity = $('#Addregion option:selected').val();
        var PostalAddress = $('#PostalAddress').val().trim();
        var PersonEmail = $('#PersonEmail').val().trim();
        var TechnicalDuty1 = $('#TechnicalDuty1 option:selected').val();
        var TechnicalDuty2 = $('#TechnicalDuty2 option:selected').val();
        var TechnicalDuty3 = $('#TechnicalDuty3 option:selected').val();
        var AddSubject = $('#AddSubject option:selected').val();
        var ResearchDirection1 = $('#ResearchDirection1').val().trim();
        var GraduationSchool = $('#GraduationSchool').val().trim();
        var AcademicDegree = $('#AcademicDegree option:selected').val();
        var ForeignLanguage = $('#ForeignLanguage').val().trim();
        var ImportantAward = $('#ImportantAward').val().trim();
        var TalentTitle = $('#TalentTitle').val().trim();
        var Mainstream = $('#Mainstream').val().trim();
        var DocumentType = $('#DocumentType option:selected').val();
        var ContactMobile = $('#ContactMobile').val().trim();
        var DateBirth = $('#DateBirth').val().trim();
        var WorkUnit = $('#WorkUnit').val().trim();
        var PostalCode = $('#PostalCode').val().trim();
        var Telephone = $('#Telephone').val().trim();
        var AdministrativeDuty = $('#AdministrativeDuty').val().trim();
        var researchField = $('#researchField  option:selected').val();
        var ResearchDirection2 = $('#ResearchDirection2').val().trim();
        var Education = $('#Education  option:selected').val();
        var WechatNumber = $('#WechatNumber').val().trim();
        var RepresentativeWork = $('#RepresentativeWork').val().trim();
        var JobStatus = $('#JobStatus').val().trim();
        var ImportantIssues = $('#ImportantIssues').val().trim();
        var Cardholder = $('#Cardholder').val().trim();
        var OpeningBranch = $('#OpeningBranch').val().trim();
        var CardNumber = $('#CardNumber').val().trim();



        if (Name == '') {
            Prompt.show("姓名不能为空", '', function() {});
            return false;
        }



        var data = {
            name: Name,
        }
        if (app.getParameterByName('NO') != null) { //编辑
            var data = {
                id: app.getParameterByName('NO')
            }
            app.posttoken(app.url.api_base + 'courses/edit', data, function(req) {
                if (req.code == 0) {

                }
            }, true)

        }
    }
    }


    new loadData();
})


// <script>
// function download()
// {
//    //下载文件的地址
//    var url="http://music.baidu.com/data/music/file?link=http://zhangmenshiting.baidu.com/data2/music/13618994/13618995183600128.mp3?xcode=48d4a720fcd9a974586066d0145f7207";
//    document.getElementById("ifile").src=url;
// }
// </script>
//   <a href="#" onclick="download()">download</a>
//   <iframe id="ifile" style="display:none"></iframe>