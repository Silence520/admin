$(function(){
		$('.Ileft').css('min-height',$(window).height()+'px');
		$('.Iright').css('min-height',$(window).height()-46+'px');
		//header 公用
		function headerhtml(){
			var html='<ul><li class="username">欢迎您！<span>xxx</span>老师</li>';
				html+='<li class="kimout">修改密码</li>';
				html+='<li class="SignOut"><i class="glyphicon glyphicon-off"></i>退出</li></ul>';
				html+='<p class="comTime"><i class="glyphicon glyphicon-time"></i>现在时间:<span class="comTimer"></span></p>';
			$('.Irtop').html(html)
		}
		//footer 公用
		function footerhtml(){
			var html='<p>版权所有：上海社会科学院尚社学人</p>';
            html+='<p>地址：中国上海市黄浦区淮海中路622弄7号 邮编：200020 电话：021-33165064 E-mail:ssxr@sass.com</p>';
            $('.comfooter').html(html);
		}
		//时间 公用
		function gettime(){
		    var data = new Date();
    		var year = data.getFullYear();
    		var mouth = data.getMonth()+1;
    		var day = data.getDate();
    		var hours = data.getHours();
    		var minut = data.getMinutes();
    		var secind = data.getSeconds();
    		if(minut<9){
    			minut='0'+ minut;
    		};
    		if(secind<9){
    			secind='0'+secind;
    		};
    		var date=year+'-'+mouth+'-'+day+' '+hours+':'+minut+':'+secind;
    		$('.comTimer').html(date);
		}
		//加载导航菜单
		// function navload(){
		// 	var data={
		// 		userId:app.getItem('userId'),
		// 	}
		// 	app.post( app.url.api_base+"menu/queryMenuList.do",dataNO,
		// 	     function(req) { 
		// 	          if(req.code==0){
		// 					var html="";
		// 					// var data=req.items;
		// 					var data={
		// 				    "code": "0",
		// 				    "result": "true",
		// 				    "message": null,
		// 				    "items": [
		// 				        {
		// 				            "id": 1,
		// 				            "uuid": null,
		// 				            "userId": null,
		// 				            "guid": null,
		// 				            "platformId": null,
		// 				            "productname": null,
		// 				            "companyId": null,
		// 				            "name": "专家信息管理",
		// 				            "htmlUrl": "",
		// 				            "parentId": 0,
		// 				            "level": 1,
		// 				            "parentName": "专家信息管理",
		// 				            "childrens": [
		// 				                {
		// 				                    "id": 2,
		// 				                    "uuid": null,
		// 				                    "userId": null,
		// 				                    "guid": null,
		// 				                    "platformId": null,
		// 				                    "productname": null,
		// 				                    "companyId": null,
		// 				                    "name": "专家信息列表",
		// 				                    "htmlUrl": "ExpertInfoList.html",
		// 				                    "parentId": 1,
		// 				                    "level": 2,
		// 				                    "parentName": "专家信息列表",
		// 				                    "childrens": null,
		// 				                    "isDeleted": null
		// 				                }
		// 				            ],
		// 				            "isDeleted": null
		// 				        },
		// 				        {
		// 				            "id": 3,
		// 				            "uuid": null,
		// 				            "userId": null,
		// 				            "guid": null,
		// 				            "platformId": null,
		// 				            "productname": null,
		// 				            "companyId": null,
		// 				            "name": "专家分配管理",
		// 				            "htmlUrl": "ExpertDistributionList.html",
		// 				            "parentId": 0,
		// 				            "level": 1,
		// 				            "parentName": "专家分配管理",
		// 				            "childrens": null,
		// 				            "isDeleted": null
		// 				        },
		// 				        {
		// 				            "id": 4,
		// 				            "uuid": null,
		// 				            "userId": null,
		// 				            "guid": null,
		// 				            "platformId": null,
		// 				            "productname": null,
		// 				            "companyId": null,
		// 				            "name": "专家评审结果管理",
		// 				            "htmlUrl": "BackExpertReviewList.html",
		// 				            "parentId": 0,
		// 				            "level": 1,
		// 				            "parentName": "专家评审结果管理",
		// 				            "childrens": null,
		// 				            "isDeleted": null
		// 				        },
		// 				        {
		// 				            "id": 5,
		// 				            "uuid": null,
		// 				            "userId": null,
		// 				            "guid": null,
		// 				            "platformId": null,
		// 				            "productname": null,
		// 				            "companyId": null,
		// 				            "name": "自动分配管理",
		// 				            "htmlUrl": "BackAutoList.html",
		// 				            "parentId": 0,
		// 				            "level": 1,
		// 				            "parentName": "自动分配管理",
		// 				            "childrens": null,
		// 				            "isDeleted": null
		// 				        },
		// 				        {
		// 				            "id": 6,
		// 				            "uuid": null,
		// 				            "userId": null,
		// 				            "guid": null,
		// 				            "platformId": null,
		// 				            "productname": null,
		// 				            "companyId": null,
		// 				            "name": "公告管理与人才政策",
		// 				            "htmlUrl": "NoticeList.html",
		// 				            "parentId": 0,
		// 				            "level": 1,
		// 				            "parentName": "公告管理与人才政策",
		// 				            "childrens": null,
		// 				            "isDeleted": null
		// 				        },
		// 				        {
		// 				            "id": 7,
		// 				            "uuid": null,
		// 				            "userId": null,
		// 				            "guid": null,
		// 				            "platformId": null,
		// 				            "productname": null,
		// 				            "companyId": null,
		// 				            "name": "批量导入",
		// 				            "htmlUrl": "ExpertInput.html",
		// 				            "parentId": 0,
		// 				            "level": 1,
		// 				            "parentName": "批量导入",
		// 				            "childrens": null,
		// 				            "isDeleted": null
		// 				        },
		// 				        {
		// 				            "id": 8,
		// 				            "uuid": null,
		// 				            "userId": null,
		// 				            "guid": null,
		// 				            "platformId": null,
		// 				            "productname": null,
		// 				            "companyId": null,
		// 				            "name": "数据概览",
		// 				            "htmlUrl": "dataView.html",
		// 				            "parentId": 0,
		// 				            "level": 1,
		// 				            "parentName": "数据概览",
		// 				            "childrens": null,
		// 				            "isDeleted": null
		// 				        },
		// 				        {
		// 				            "id": 9,
		// 				            "uuid": null,
		// 				            "userId": null,
		// 				            "guid": null,
		// 				            "platformId": null,
		// 				            "productname": null,
		// 				            "companyId": null,
		// 				            "name": "机构维护",
		// 				            "htmlUrl": "BackCompanyList.html",
		// 				            "parentId": 0,
		// 				            "level": 1,
		// 				            "parentName": "机构维护",
		// 				            "childrens": null,
		// 				            "isDeleted": null
		// 				        },
		// 				        {
		// 				            "id": 10,
		// 				            "uuid": null,
		// 				            "userId": null,
		// 				            "guid": null,
		// 				            "platformId": null,
		// 				            "productname": null,
		// 				            "companyId": null,
		// 				            "name": "管理用户维护",
		// 				            "htmlUrl": "BackUserList.html",
		// 				            "parentId": 0,
		// 				            "level": 1,
		// 				            "parentName": "管理用户维护",
		// 				            "childrens": null,
		// 				            "isDeleted": null
		// 				        },
		// 				        {
		// 				            "id": 11,
		// 				            "uuid": null,
		// 				            "userId": null,
		// 				            "guid": null,
		// 				            "platformId": null,
		// 				            "productname": null,
		// 				            "companyId": null,
		// 				            "name": "角色管理",
		// 				            "htmlUrl": "BackRoleList.html",
		// 				            "parentId": 0,
		// 				            "level": 1,
		// 				            "parentName": "角色管理",
		// 				            "childrens": null,
		// 				            "isDeleted": null
		// 				        },
		// 				        {
		// 				            "id": 12,
		// 				            "uuid": null,
		// 				            "userId": null,
		// 				            "guid": null,
		// 				            "platformId": null,
		// 				            "productname": null,
		// 				            "companyId": null,
		// 				            "name": "政策文件",
		// 				            "htmlUrl": "PolicyNotice.html",
		// 				            "parentId": 0,
		// 				            "level": 1,
		// 				            "parentName": "政策文件",
		// 				            "childrens": null,
		// 				            "isDeleted": null
		// 				        },
		// 				        {
		// 				            "id": 13,
		// 				            "uuid": null,
		// 				            "userId": null,
		// 				            "guid": null,
		// 				            "platformId": null,
		// 				            "productname": null,
		// 				            "companyId": null,
		// 				            "name": "政策文件发布",
		// 				            "htmlUrl": "BackPolicyNoticeList.html",
		// 				            "parentId": 0,
		// 				            "level": 1,
		// 				            "parentName": "政策文件发布",
		// 				            "childrens": null,
		// 				            "isDeleted": null
		// 				        },
		// 				        {
		// 				            "id": 14,
		// 				            "uuid": null,
		// 				            "userId": null,
		// 				            "guid": null,
		// 				            "platformId": null,
		// 				            "productname": null,
		// 				            "companyId": null,
		// 				            "name": "评审模板管理",
		// 				            "htmlUrl": "BackTempList.html",
		// 				            "parentId": 0,
		// 				            "level": 1,
		// 				            "parentName": "评审模板管理",
		// 				            "childrens": null,
		// 				            "isDeleted": null
		// 				        },
		// 				        {
		// 				            "id": 22,
		// 				            "uuid": null,
		// 				            "userId": null,
		// 				            "guid": null,
		// 				            "platformId": null,
		// 				            "productname": null,
		// 				            "companyId": null,
		// 				            "name": "代表作管理",
		// 				            "htmlUrl": "InputWorkList.html",
		// 				            "parentId": 0,
		// 				            "level": 1,
		// 				            "parentName": "代表作管理",
		// 				            "childrens": null,
		// 				            "isDeleted": null
		// 				        }
		// 				    ],
		// 				    "totalcount": null
		// 				};
		// 					$.each(data.items,function(i,v){
		// 						if(v.childrens!=null){
		// 						html+='<p><i class="glyphicon glyphicon-th-list"></i>'+v.name+'</p>';
		// 						html+='<div>';
		// 						$.each(v.childrens,function(x,z){
		// 							html+='<a href="'+z.htmlUrl+'" class="list-group-item active">'+z.name+'</a>';
		// 						})
		// 						html+='</div>';	
		// 						}
		// 					})
		// 					$('.margintop .list-group').html(html);
		// 	           }else{
		// 	             Prompt.show(req.message)
		// 	           }
		// 	     },true);
		// }
		// navload();
		gettime();
		headerhtml();
		footerhtml();
		setInterval(function(){
		    gettime();
		},1000);
		//判断是否登陆
		if(app.getItem('userName')){
			function loadData(){
				this.data={
					
				}
				this.init();
			}
		}else{
			app.go('login.html')
		}
		loadData.prototype.init=function(){
			$('.username span').html(app.getItem('userName'));
			var _this=this;
			//退出
			$(document).on('click','.SignOut',function(){
				app.removeItem('companyId')
				app.removeItem('userName')
				app.removeItem('userId')
				app.removeItem('userToken')
				app.go('login.html');

			})

			//导航
			$(document).on('click','.margintop .list-group p',function(){
				$('.Ileft .list-group div').hide();
				$(this).next('div').show();
			})
			//修改密码
			$(document).on('click','.kimout',function(){
				
			})	

		}

		new loadData();
})


