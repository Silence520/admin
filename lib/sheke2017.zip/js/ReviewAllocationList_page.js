$(function() {

	//判断是否登陆
	if(app.getItem('user') !=''){
		function loadData(){
			this.data={
				pageIndex: 1,
                everyPage: 20,
			}
			this.init();
		}
	}else{
		app.go('login.html')
	}


	//原型读写数据
	loadData.prototype.init=function(){
		var _this=this;


	//搜索
	//线索搜索提交
	$(document).on('click', '.btnsearch', function() {
	    var SeaName = $('#SeaName').val();
	    var SeaPhone = $('#SeaPhone').val();
	    var html = '<span>热搜词：</span>';
	    if (SeaName != '') {
	        html += '<span>' + SeaName + '</span>';
	    }
	    if (SeaPhone != '') {
	        html += '<span>' + SeaPhone + '</span>';
	    }
	   
	    _this.data.name = SeaName;
	    _this.data.mobile = SeaPhone;
	  
	    // _this.data.pageIndex = 1;
	    // _this.data.everyPage = 10;
	   
	    $('.searchCriteria').html(html)
	    if ($('.searchCriteria').find('span').length > 1) {
	        $('#pageToolbar,.table').hide();
	        // var type = $('.Administrationtab .active').attr('itype');
	        adddata(_this.data);
	    } else {
	        Prompt.show("搜索条件为空！", '操作提示', function() {});
	        return false;
	    }

	});

	//重置搜索条件
    $(document).on('click', '.iRefresh', function() {
        _this.data.name = '';
        _this.data.mobile = '';
        $('#pageToolbar,.table').hide();
        // var type = $('.Administrationtab .active').attr('itype');
        adddata(_this.data);
        $('.searchCriteria').html('<span>热搜词：</span>')

    });

	//分页
	$('#pageToolbar').Paging({
                pagesize: 10,
                count: 200,
                toolbar: true,
                callback: function(page, size, count) {
                    if (page == NaN) {
                        page = parseInt($('#pageToolbar . ').html())
                    }
                    var data = _this.data;
                    data.pageIndex = page;
                    // var type = app.getParameterByName('itype');
                    adddata(data);
                },
                callbacktwo: function(page, size, count) {
                    var pagenum = parseInt(size);
                    console.log(isNaN(pagenum))
                    if (isNaN(pagenum)) {
                        console.log($('.ui-select-pagesize option:selected').val())
                        pagenum = $('.ui-select-pagesize option:selected').val();
                    }
                    var data = _this.data;
                    console.log(data)
                    data.everyPage = pagenum;

                    // data.everyPage = pagenum;
                    var type = app.getParameterByName('itype');
                    adddata(data);
                }
            });

	//加载数据
	function adddata(data,type){
		app.posttoken(app.url.api_base + "leads/list", data,
		    function(req) {
		        if (req.code == 0) {
		            var data = req.data.list;
		            if (data.length > 0) {
		                var html = '';
		                $.each(data, function(i, v) {
		                	html+='<tr>';
		                	html+='<td>20170602-00001';
		                	html+='</td>';
		                	html+='<td>张小明';
		                	html+='</td>';
		                	html+='<td>党建';
		                	html+='</td>';
		                	html+='<td>副高';
		                	html+='</td>';
		                	html+='<td>钱运春';
		                	html+='</td>';
		                	html+='<td>2016091400066';
		                	html+='</td>';
		                	html+='<td>审核通过，待鉴定';
		                	html+='</td>';
		                	html+='<td>';
		                	html+='<span>审核通过';
		                	html+='</span>';
		                	html+='<span>手动调整';
		                	html+='</span>';
		                	html+='</td>';
		                	html+='</tr>';
		                })
		                $('.table tbody').html(html);
		                if (_this.data.pageIndex == 1 && _this.data.everyPage == 10) {
		                    $('#pageToolbar').html('');
		                    pagefen(_this.data.everyPage, req.data.count);
		                }
		                $('.table,#pageToolbar').fadeIn(300);;
		                $('.Inothing').hide();
		            } else {
		                // Prompt.show("抱歉！没有数据", '操作提示', function() {});
		                // return false;
		                $('.Inothing').show();
		            }
		        } else {
		            Prompt.show(req.message);
		        }
		        $('.icontent').fadeIn(100)
		    });
	}






















	}


















 new loadData();	
})

