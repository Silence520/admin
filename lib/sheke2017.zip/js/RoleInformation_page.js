$(function(){
	//判断是否登陆

	if(app.getItem('userName')){
        function loadData(){
            this.data={}
            this.init();
        }
    }else{
        app.go('login.html')
    }

	loadData.prototype.init=function(){
		var _this=this;
		var dataNO={
				userToken:app.getItem('userToken'),
                userId:app.getItem('userId'),
				}
		app.post( app.url.api_base+"menu/queryMenuList.do",dataNO,
	     function(req) { 
	          if(req.code==0){
					var html="";
					// var data=req.items;
					var data={
				    "code": "0",
				    "result": "true",
				    "message": null,
				    "items": [
				        {
				            "id": 1,
				            "uuid": null,
				            "userId": null,
				            "guid": null,
				            "platformId": null,
				            "productname": null,
				            "companyId": null,
				            "name": "专家信息管理",
				            "htmlUrl": "",
				            "parentId": 0,
				            "level": 1,
				            "parentName": "专家信息管理",
				            "childrens": [
				                {
				                    "id": 2,
				                    "uuid": null,
				                    "userId": null,
				                    "guid": null,
				                    "platformId": null,
				                    "productname": null,
				                    "companyId": null,
				                    "name": "专家信息列表",
				                    "htmlUrl": "ExpertInfoList.html",
				                    "parentId": 1,
				                    "level": 2,
				                    "parentName": "专家信息列表",
				                    "childrens": null,
				                    "isDeleted": null
				                }
				            ],
				            "isDeleted": null
				        },
				        {
				            "id": 3,
				            "uuid": null,
				            "userId": null,
				            "guid": null,
				            "platformId": null,
				            "productname": null,
				            "companyId": null,
				            "name": "专家分配管理",
				            "htmlUrl": "ExpertDistributionList.html",
				            "parentId": 0,
				            "level": 1,
				            "parentName": "专家分配管理",
				            "childrens": null,
				            "isDeleted": null
				        },
				        {
				            "id": 4,
				            "uuid": null,
				            "userId": null,
				            "guid": null,
				            "platformId": null,
				            "productname": null,
				            "companyId": null,
				            "name": "专家评审结果管理",
				            "htmlUrl": "BackExpertReviewList.html",
				            "parentId": 0,
				            "level": 1,
				            "parentName": "专家评审结果管理",
				            "childrens": null,
				            "isDeleted": null
				        },
				        {
				            "id": 5,
				            "uuid": null,
				            "userId": null,
				            "guid": null,
				            "platformId": null,
				            "productname": null,
				            "companyId": null,
				            "name": "自动分配管理",
				            "htmlUrl": "BackAutoList.html",
				            "parentId": 0,
				            "level": 1,
				            "parentName": "自动分配管理",
				            "childrens": null,
				            "isDeleted": null
				        },
				        {
				            "id": 6,
				            "uuid": null,
				            "userId": null,
				            "guid": null,
				            "platformId": null,
				            "productname": null,
				            "companyId": null,
				            "name": "公告管理与人才政策",
				            "htmlUrl": "NoticeList.html",
				            "parentId": 0,
				            "level": 1,
				            "parentName": "公告管理与人才政策",
				            "childrens": null,
				            "isDeleted": null
				        },
				        {
				            "id": 7,
				            "uuid": null,
				            "userId": null,
				            "guid": null,
				            "platformId": null,
				            "productname": null,
				            "companyId": null,
				            "name": "批量导入",
				            "htmlUrl": "ExpertInput.html",
				            "parentId": 0,
				            "level": 1,
				            "parentName": "批量导入",
				            "childrens": null,
				            "isDeleted": null
				        },
				        {
				            "id": 8,
				            "uuid": null,
				            "userId": null,
				            "guid": null,
				            "platformId": null,
				            "productname": null,
				            "companyId": null,
				            "name": "数据概览",
				            "htmlUrl": "dataView.html",
				            "parentId": 0,
				            "level": 1,
				            "parentName": "数据概览",
				            "childrens": null,
				            "isDeleted": null
				        },
				        {
				            "id": 9,
				            "uuid": null,
				            "userId": null,
				            "guid": null,
				            "platformId": null,
				            "productname": null,
				            "companyId": null,
				            "name": "机构维护",
				            "htmlUrl": "BackCompanyList.html",
				            "parentId": 0,
				            "level": 1,
				            "parentName": "机构维护",
				            "childrens": null,
				            "isDeleted": null
				        },
				        {
				            "id": 10,
				            "uuid": null,
				            "userId": null,
				            "guid": null,
				            "platformId": null,
				            "productname": null,
				            "companyId": null,
				            "name": "管理用户维护",
				            "htmlUrl": "BackUserList.html",
				            "parentId": 0,
				            "level": 1,
				            "parentName": "管理用户维护",
				            "childrens": null,
				            "isDeleted": null
				        },
				        {
				            "id": 11,
				            "uuid": null,
				            "userId": null,
				            "guid": null,
				            "platformId": null,
				            "productname": null,
				            "companyId": null,
				            "name": "角色管理",
				            "htmlUrl": "BackRoleList.html",
				            "parentId": 0,
				            "level": 1,
				            "parentName": "角色管理",
				            "childrens": null,
				            "isDeleted": null
				        },
				        {
				            "id": 12,
				            "uuid": null,
				            "userId": null,
				            "guid": null,
				            "platformId": null,
				            "productname": null,
				            "companyId": null,
				            "name": "政策文件",
				            "htmlUrl": "PolicyNotice.html",
				            "parentId": 0,
				            "level": 1,
				            "parentName": "政策文件",
				            "childrens": null,
				            "isDeleted": null
				        },
				        {
				            "id": 13,
				            "uuid": null,
				            "userId": null,
				            "guid": null,
				            "platformId": null,
				            "productname": null,
				            "companyId": null,
				            "name": "政策文件发布",
				            "htmlUrl": "BackPolicyNoticeList.html",
				            "parentId": 0,
				            "level": 1,
				            "parentName": "政策文件发布",
				            "childrens": null,
				            "isDeleted": null
				        },
				        {
				            "id": 14,
				            "uuid": null,
				            "userId": null,
				            "guid": null,
				            "platformId": null,
				            "productname": null,
				            "companyId": null,
				            "name": "评审模板管理",
				            "htmlUrl": "BackTempList.html",
				            "parentId": 0,
				            "level": 1,
				            "parentName": "评审模板管理",
				            "childrens": null,
				            "isDeleted": null
				        },
				        {
				            "id": 22,
				            "uuid": null,
				            "userId": null,
				            "guid": null,
				            "platformId": null,
				            "productname": null,
				            "companyId": null,
				            "name": "代表作管理",
				            "htmlUrl": "InputWorkList.html",
				            "parentId": 0,
				            "level": 1,
				            "parentName": "代表作管理",
				            "childrens": null,
				            "isDeleted": null
				        }
				    ],
				    "totalcount": null
				};
					$.each(data.items,function(i,v){
						 html+='<tr>';
						 html+='<td> ';
						 html+='<label><input type="checkbox" dataId="'+v.id+'" class="CheckAll">'+v.name+'</label>';
						 html+='</td>';
						 html+='<td>';
						if(v.childrens!=null){
						$.each(v.childrens,function(x,z){
						 html+='<label><input type="checkbox" dataId="'+z.id+'" class="CheckOne">'+z.name+'</label>';	
						})
						}
						 html+='</td>';
						 html+='</tr>';
					})
					$('.table.table-striped tbody').html(html);
	           }else{
	             Prompt.show(req.message)
	           }
	     },true);
		//判断是修改还是新建
		var roleId = app.getParameterByName('NO');
		if(roleId){
				//获取要编辑的
				var dataNO={
						userToken:app.getItem('userToken'),
		                userId:app.getItem('userId'),
						}
				app.post( app.url.api_base+"menu/queryMenuList.do",dataNO,
			     function(req) { 
			          if(req.code==0){
							$('#RoleCode').val();
							$('#RoleName').val();
							$('#id="RoleDesc"').val();

			           }else{
			             Prompt.show(req.message)
			           }
			     },true);
		
			
		}
		//返回
		$(document).on('click','goBack',function(){
			app.back();
		})


		//单个全选
		$(document).on('click', '.tablenav .CheckAll', function() {

		    if ($(this).is(':checked')) {
		    	$(this).parents('td').next('td').find('input[type="checkbox"]').prop('checked', true);
		    } else {
		        $(this).parents('.table').find('input[type="checkbox"]').prop('checked', false);
		    } 
		});

		//分配全选
		$(document).on('click', '.tablenav .CheckOne',function(){
			var num=0;
			var node=$(this).parents('td');
			$(node).find('input').each(function(){
			console.log('1')
				if($(this).is(':checked')==false){
					num=1;
				}
				if(num==1){
					$(this).parents('td').prev('td').find('input').prop('checked', false);
				}else{
					$(this).parents('td').prev('td').find('input').prop('checked', true)
				}
			})
		});



		//提交数据
		$(document).on('click','DeSubmine',function(){
			var RoleCode=$('#RoleCode').val();
			var RoleName=$('#RoleName').val();
			var RoleDesc=$('#RoleDesc').val();
			var Interest='';
			$('.addcourse .active').each(function() {
            	Interest += $(this).attr('id') + ','
        	});
			var newstr = Interest.substring(0, Interest.length - 1);
			if (RoleCode == '') {
			    Prompt.show('角色代码为空!', '操作提示', function() {});
			    return false;
			}
			if (RoleName == '') {
			    Prompt.show('角色名称为空!', '操作提示', function() {});
			    return false;
			}
			if (RoleDesc == '') {
			    Prompt.show('角色描述为空!', '操作提示', function() {});
			    return false;
			}
			if (newstr == '') {
			    Prompt.show('菜单权限不能为空!', '操作提示', function() {});
			    return false;
			}
			
			var data={};
			data.roleCode =RoleCode;
			data.roleName =RoleName;
			data.roleDesc =RoleDesc;
			data.DeSubmine=newstr;
			if(roleId){//修改
				data.id=roleId;
				app.post( app.url.api_base+"menuRole/updateUserMenu.do",data,
			     function(req) { 
			          Prompt.show(req.message);
			     },true);
			}else{ //新建
				app.post( app.url.api_base+"menuRole/saveUserMenu.do",data,
			     function(req) { 
			          Prompt.show(req.message);
			     },true);
			}
		})
		
	}

	new loadData();
})

