$(function() {
    function loadData() {
        this.data = {
            pageIndex: 1,
            everyPage: 10,
            country:'',
            province:'',
            city:'',
            area:'',
            type:'',
        };
        this.init();
    }

    loadData.prototype.init = function() {
        var _this = this;
        // laadData();
        getcountry();

        //查询
        $(document).on('click', '.sea-btn', function() {
            laadData();
        })

        //导出报表
        $(document).on('click', '.export-btn', function() {
                window.open(app.url.api_base + "schools/main/exportSchoolResult")
        })

        //mode loaddata
        $(document).on('click', '.add-more-data span', function() {
              _this.data.pageIndex+=1;
              laadData();
        })

        //国家
        $(document).on('change','#country',function(){
                $('#province option').remove();
                $('#city option').remove();
                $('#area option').remove();
                var num = $('#country').val();
                _this.data.country=num;
                _this.data.province='';
                _this.data.city='';
                _this.data.area='';
                getprovince(num)
        })
        //省份
        $(document).on('change', '#province', function() {
                $('#city option').remove();
                $('#area option').remove();
                var num = $('#province').val();
                _this.data.province=num;
                _this.data.city='';
                _this.data.area='';
                getcity(num)
        });

         //城市
        $(document).on('change', '#city', function() {
                    $('#area option').remove();
                    var num = $('#city').val();
                    _this.data.city=num;
                    _this.data.area='';
                    getarea(num)
        });

        //地区
        $(document).on('change', '#area', function() {
                    var num = $('#area').val();
                    _this.data.area=num;
        });

        //获取国家
        function getcountry(){
          var data = {
                         'level': 1
                  };
            app.posttoken(app.url.api_base + "/schools/main/areaListJsonResult",data,
                    function(req) {
                        if (req.code == 0) {
                            var data = req.data;
                            if (data.length > 0) {
                                var html = '<option value="">请选择</option>';
                                $.each(data, function(i, v) {
                                    html += '<option value="' + v. name+ '">' + v.name + '</option>';
                                });
                                $('#country').html(html);
                            }
                        } else {
                            Prompt.show(req.message);
                        }
                    });
        }

        //获取省份
        function getprovince(num){
          var data = {
                   'code': num,
                   'level': 2
            };
            app.posttoken(app.url.api_base + "/schools/main/areaListJsonResult",data,
                    function(req) {
                        if (req.code == 0) {
                            var data = req.data;
                            if (data.length > 0) {
                                var html = '<option value="">请选择</option>';
                                $.each(data, function(i, v) {
                                    html += '<option value="' + v. name+ '">' + v.name + '</option>';
                                });
                                $('#province').html(html);
                            }
                        } else {
                            Prompt.show(req.message);
                        }
                    });
             }

         //获取城市
        function getcity(num){
            var data = {
                   'code': num,
                   'level': 3
            };
            app.posttoken(app.url.api_base + "/schools/main/areaListJsonResult", data,
                     function(req) {
                        if (req.code == 0) {
                            var data = req.data;
                            if (data.length > 0) {
                                var html = '<option value="">请选择</option>';
                                $.each(data, function(i, v) {
                                    html += '<option value="' + v. name+ '">' + v.name + '</option>';
                                });
                                $('#city').html(html);
                            }
                        } else {
                            Prompt.show(req.message);
                        }
                    });
             }

             //获取地区
           function getarea(num){
                   var data = {
                          'code': num,
                         'level': 4
                         };
                    app.posttoken(app.url.api_base + "/schools/main/areaListJsonResult", data,
                            function(req) {
                               if (req.code == 0) {
                                   var data = req.data;
                                   if (data.length > 0) {
                                       var html = '<option value="">请选择</option>';
                                       $.each(data, function(i, v) {
                                           html += '<option value="' + v.name + '">' + v.name + '</option>';
                                       });
                                       $('#area').html(html);
                                   }
                               } else {
                                   Prompt.show(req.message);
                               }
                    });
             }

             //获取数据 
             function laadData() {
                  var data={
                        'pageNo':   _this.data.pageIndex,
                        'everyPage': _this.data.everyPage,
                        'province':_this.data.province,
                        'city':_this.data.city,
                        'district':_this.data.area,
                        'country':_this.data.country
                  }
                 app.posttoken(app.url.api_base + "schools/main/campusMarketplace", data,
                        function(req) {
                             var html='';
                             $.each(req,function(i,v){
                                           html+='<tr>';
                                           html+='<td> <input type="checkbox" ></td>';
                                           html+='<td>'+(i+1)+'</td>';
                                           html+='<td>'+replace(v.area)+'</td>';
                                           html+='<td>'+replace(v.schoolName)+'</td>';
                                           if (v.memberListCount>0) {
                                                html+='<td><a href="maillist.html?NO='+v.schoolName+'"  target="_blank">'+replace(v.memberListCount)+'</a></td>';
                                            }else{
                                                html+='<td>'+replace(v.memberListCount)+'</td>';
                                            }
                                            if (v.areaCount>0) {
                                                html+='<td><a href="campuslist.html?NO='+v.schoolName+'"  target="_blank">'+replace(v.areaCount)+'</a></td>';
                                            }else{
                                                html+='<td>'+replace(v.areaCount)+'</td>';
                                            }
                                           
                                           if(v.onLineCount>0){
                                                html+='<td><a href="online.html?NO='+v.schoolName+'"  target="_blank">'+replace(v.onLineCount)+'</a></td>';
                                           }else{
                                                html+='<td>'+replace(v.onLineCount)+'</td>';
                                           }
                                           html+='<td>¥ '+replace(v.onLinePeriodicalPriceCount)+'</td>';
                                            if(v.offLineCount>0){
                                                html+='<td><a href="offlineresources.html?NO='+v.schoolName+'"  target="_blank">'+replace(v.offLineCount)+'</a></td>';
                                           }else{
                                                html+='<td>'+replace(v.offLineCount)+'</td>';
                                           }
                                           
                                           html+='<td>¥ '+replace(v.offLinePeriodicalPriceCount)+'</td>';
                                           html+='<td>'+replace(v.openStatus)+'</td>';
                                           html+='</tr>';
                             })
                             if(_this.data.pageIndex>1){
                                    $('.table>tbody').append(html)
                             }else{
                                    $('.table>tbody').html(html)
                             }
                   });   
             }
        };

    new loadData();
});